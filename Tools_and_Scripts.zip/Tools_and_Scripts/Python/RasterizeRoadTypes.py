# ---------------------------------------------------------------------------
# RasterRoadTypes.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-05-05
# Last Edit: 2016-05-05
# Creator:  Kirsten R. Hazler
#
# Summary:
# Creates a separate raster for each road type in an input polyline feature class.
# It is assumed that the input roads are of three types coded as follows:
#     0 = regular roads
#     1 = highway access ramps
#     2 = limited access highways
#
# Usage Tips:
#
# Syntax: 
# RasterRoadTypes <in_Roads> <fld_RType> <in_Snap> <out_GDB> 
# ---------------------------------------------------------------------------

# Import modules
import arcpy
import os # provides access to operating system funtionality 
import sys # provides access to Python system functions
import traceback # used for error handling

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

# Script arguments to be input by user
in_Roads = arcpy.GetParameterAsText(0) # Input feature class representing roads
fld_RType = arcpy.GetParameterAsText(1) # Integer field indicating road type
   # Default: "RmpHwy"
in_Snap = arcpy.GetParameterAsText(2) # Input snap raster (5-m resampled NLCD)
   # Default : \nlcdVA_albers.gdb\nlcd2011_imp5"
out_GDB = arcpy.GetParameterAsText(3) # Geodatabase to store outputs

# Additional variables and environment settings:
arcpy.env.snapRaster = in_Snap
arcpy.env.mask = in_Snap
arcpy.env.overwriteOutput = True 

# Create a new temporary feature class for each road type, then rasterize it
for rType in [(0, "reg"), (1, "rmp"), (2, "hwy")]:
   # Select and copy features
   type_val = rType[0]
   out_name = "road_" + rType[1]
   where_clause = "%s = %s" %(fld_RType, str(type_val))
   arcpy.AddMessage("Selecting and copying roads (%s)" % str(type_val))
   arcpy.FeatureClassToFeatureClass_conversion (in_Roads, out_GDB, out_name, where_clause)
   
   # Set type field to the value 1
   roads_line = out_GDB + os.sep + out_name
   arcpy.CalculateField_management (roads_line, fld_RType, 1, "PYTHON")
   
   # Rasterize roads
   roads_raster = out_GDB + os.sep + "rd_" + out_name
   arcpy.AddMessage("Rasterizing roads (%s)" % str(type_val))
   arcpy.PolylineToRaster_conversion(roads_line, fld_RType, roads_raster, "MAXIMUM_LENGTH", fld_RType, in_Snap)


