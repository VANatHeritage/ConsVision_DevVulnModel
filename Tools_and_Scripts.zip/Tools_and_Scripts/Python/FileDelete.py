# ------------------------------------------------------------------------------------------
# FileDelete.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-12-04
# Last Edit:  2013-12-04
# Creator:  Kirsten R. Hazler
#
# Summary:
#     Within source directory, deletes all files except TAR.GZ files.  This is to save space
#     storing Landsat files.
#
# Usage Tips:
#
# Required Arguments:
#     SrcDir:  The main directory
# ------------------------------------------------------------------------------------------

# Import required standard modules
import os, sys, traceback

# Hard-coded script arguments
SrcDir = r"I:\Landsat\Landsat_L1T"

#Get the list of images to process
mySrcFiles = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(SrcDir)
             for f in files if not f.endswith('tar.gz')]
            
for myfile in mySrcFiles:
   try:
      print "Deleting " + myfile

      # Delete the file
      os.remove(myfile)
         
   except:
      # Error handling code modified from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      print pymsg


