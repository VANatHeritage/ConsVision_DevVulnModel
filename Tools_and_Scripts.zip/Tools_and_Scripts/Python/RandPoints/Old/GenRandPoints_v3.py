# GEN_POINTS.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-06-25
# Creator:  Roy D. Gilb
#
# Summary: Creates a specified number of random point features on a classified raster layer.
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:
#
#  *input_raster: the intended 
#  *numpoints
#  *output_path
#  *min_dist
#  *excluded_class


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env
from arcpy.sa import *

#Set workspace variables
myRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints'
binRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters'

arcpy.env.workspace = myRoot            #Set workspace

#Parameters passed in from arc tool
inRastText = arcpy.GetParameterAsText(0)
numPoints = arcpy.GetParameterAsText(1)
outputPath = arcpy.GetParameterAsText(2)
minDistance = arcpy.GetParameterAsText(3)
excludedClass = arcpy.GetParameterAsText(4)

#Local variables
GME_file = 'C:\Software\SEGME.exe'              #Not used
inRaster = Raster(inRastText)                   #Create raster variable from parameter input text
myArray = arcpy.RasterToNumPyArray(inRastText)  #Create a numpyarray of the input raster for extracting unique values
uniqueVals = np.unique(myArray)                 #Extract unique values
count = 1                                       #For indexing and giving user feedback

#Inform user of processes
arcpy.AddMessage('Parameters for processing are:\nInput Raster: ' + inRastText + '\nNumber of Sample Points: ' + numPoints + '\nOutput Path: ' + outputPath)


#BINARY RASTER LOOPS
os.chdir("C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\BinRasters")

arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))
arcpy.AddMessage('Beginning binary raster creation')
    
    
#Loops to create a binary raster for each feature class in the input raster (should be a total of 14 binary rasters for NLCD data)
for val in uniqueVals:
    arcpy.AddMessage('Creating binary raster of class ' + str(val))     #Give user some processing feedback
   
    #Create a variable for the path/name of the unique binary rasters based on their value
    binRasterPath = 'C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\BinRasters\\binaryClass' 
    binRasterPath = binRasterPath + str(val)
   
    #Use a conditional statement to extract just the values within the raster that match the unique class value for the iteration
    outRaster = Con((inRaster == int(val)), 1)       
    outRaster.save(binRasterPath)                   #Save a binary raster with either 1 or NoData for each class value
    
    #Create properly formatted string for running GME genrandompnts command and write that string to a unique txt file
    myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + 'C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\BinRasters\\binaryClass' + str(val) + ".shp" + "\", " + "pnd=TRUE);"
    textFile = open("binaryClass" + str(val) + ".txt", "w")
    textFile.write(myInfo)                                      #Populate the txt file with a GME command 
    textFile.close()
    
    
#CORRECT RUN CALL TO GME TXT SCRIPT ---- NOT USED
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Python_Scripts\GME_SCRIPT.txt\");');
    
   
try:
#Recursively walk through all files and directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(binRoot):
      for filename in myFiles: 
         if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
            #Change current directory to the directory referenced by walk (contains txt files)
            os.chdir(binRoot)
            
            #Properly format the GME call as a string and use subprocess.call to run the GME script from within each txt file
            gmeCall = r'C:\\Software\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters' + '\\' + filename + '\\");'       #\");');        #[11: filename.find('.txt')] + '.txt\\'");"
            subp.call(gmeCall);             #subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\");');
            
            #User feedback
            arcpy.AddMessage((str(count) + ") Running file: " + filename))
            count = count + 1
            

#Error handling
except IOError:
   arcpy.AddMessage("Error: can\'t find file or read data.")
else:
   arcpy.AddMessage("Successfully ran GME scripts.")

  
#Create new fields in shpfiles to keep original class values 
#Merge shapefiles into one whiel retaining class values from raster    
    

#Merge shapefiles
tmp = "binaryClass"
os.chdir("C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters")
arcpy.env.workspace = binRoot

#Get a list of all the shapefiles containing random sample points on each raster class value
fcs = arcpy.ListFeatureClasses()

for fc in fcs:
  tmpVal = fc[11: fc.find('.shp')]      #Substring call on the feature classes filename to extract the original class number
  arcpy.AddField_management(fc, 'CLASSVALUE','text')    #Add a field called CLASSVALUE
  arcpy.CalculateField_management(fc, 'CLASSVALUE', '"'+tmpVal+'"')
arcpy.Merge_management(fcs, 'randPointsOut.shp')                                    #Code idea from http://gis.stackexchange.com/questions/7007/batch-shapefile-merge-with-adding-and-calculating-field
    
 
#ADD BUFFER TO POINTS ???

#CALL PAIRED SAMPLE POINT SUBROUTINE  ???
 