#Paired_Points.py
#Roy Gilb
#June 26, 2013

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env
from arcpy.sa import *

#Parameters passed in from arc tool
inputPoints = arcpy.GetParameterAsText(0)
myOut = arcpy.GetParameterAsText(1)
myRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints'
binRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters'
pairedRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints'
uniqueList = []
count = 0


#Get unique values for the rasters 
os.chdir(binRoot)
try:
#Recursively walk through all files and directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(binRoot):
      for filename in myFiles: 
         if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
            s = filename[11:13]
            uniqueList.append(s)           

#Error handling
except IOError:
   arcpy.AddMessage("Error: can\'t find file or read data.")
else:
   arcpy.AddMessage("Successfully ran GME scripts.")




#Loop to create txt GME scripts in PairedPoints directory
for val in uniqueList:
    arcpy.AddMessage('Creating GME Script files making paired sample points ' + str(val))     #Give user some processing feedback
   
    #Create a string variable for the path/name of the unique point shapefiles based on their value to access the 
    binPointPath = 'C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\BinRasters\\binaryClass' 
    binPointPath = binPointPath + str(val) + '.shp'
   
   
    os.chdir('C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\PairedPoints')
    
    #Create properly formatted string for running GME gencondrandompnts command and write that string to a unique txt file
    myInfo = "gencondrandompnts(in=\"" + str(binPointPath) + "\", "  + "uidfield=\"FID\""  + ", sample=\"1\"" + ", distrib=c(\"" + "BVUNIFORM\"" + ", 50, 5000)" + ", out=\"" + 'C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\PairedPoints\\pairedClass' + str(val) + ".shp" + "\");"
    textFile = open("pairedClass" + str(val) + ".txt", "w")
    textFile.write(myInfo)                                      #Populate the txt file with a GME command 
    textFile.close()
    



#Loop to call txt GME scripts within PairedPoints directory
#FROM GenRandPoints.py code

try:
#Recursively walk through all files and directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(pairedRoot):
      for filename in myFiles: 
         if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
            #Change current directory to the directory referenced by walk (contains txt files)
            os.chdir(pairedRoot)
            
            #Properly format the GME call as a string and use subprocess.call to run the GME script from within each txt file
            gmeCall = r'C:\\Software\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints' + '\\' + filename + '\\");'      
            subp.call(gmeCall);             #subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\");');
            
            #User feedback
            arcpy.AddMessage((str(count) + ") Running file: " + filename))
            count = count + 1
            

#Error handling
except IOError:
   arcpy.AddMessage("Error: can\'t find file or read data.")
else:
   arcpy.AddMessage("Successfully ran GME scripts.")


   
#Merge shapefiles
tmp = "pairedClass"
os.chdir("C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints")
arcpy.env.workspace = pairedRoot

#Get a list of all the shapefiles containing random sample points on each raster class value
fcs = arcpy.ListFeatureClasses()

for fc in fcs:
  tmpVal = fc[11: fc.find('.shp')]      #Substring call on the feature classes filename to extract the original class number
  arcpy.AddField_management(fc, 'CLASSVALUE','text')    #Add a field called CLASSVALUE
  arcpy.CalculateField_management(fc, 'CLASSVALUE', '"'+tmpVal+'"')
arcpy.Merge_management(fcs, 'pairedPointsOut.shp')                                    #Code idea from http://gis.stackexchange.com/questions/7007/batch-shapefile-merge-with-adding-and-calculating-field
    
 
   
   
#GME CALL
#gencondrandompnts(in="C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\myOut.shp", uidfield="FID", sample="1", distrib=c("BVUNIFORM", 22, 55), out="C:\Gilb_VulnMod\Arc_Test\Shp\cond_points1.shp");
