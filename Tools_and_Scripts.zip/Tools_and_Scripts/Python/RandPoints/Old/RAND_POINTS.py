#RAND_POINTS.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-17
# Last Edit: 2013-06-17
# Creator:  Roy D. Gilb
#
# Summary:
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:
#
#  *input_raster
#  *numpoints
#  *output_path
#  *min_dist
#  *excluded_class


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env

#parameters
input_raster = arcpy.GetParameterAsText(0)
numpoints = arcpy.GetParameterAsText(1)
output_path = arcpy.GetParameterAsText(2)
min_dist = arcpy.GetParameterAsText(3)
excluded_class = arcpy.GetParameterAsText(4)

#local variables
GME_file = 'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe'

#Inform user of processes
arcpy.AddMessage('Your parameters are:\nInput Raster: ' + input_raster + '\nNumber of Sample Points: ' + numpoints + '\nOutput Path: ' + output_path)




myArray = arcpy.RasterToNumPyArray(input_raster)
[rows, cols] = myArray.shape
totalElements = cols * rows
uniqueVals = np.unique(myArray)
rastDict = {}
tempArray = np.zeros([rows, cols])


arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))

arcpy.AddMessage('Processing Rasters')


#Loops to create a binary raster for each feature class in the input raster
for val in uniqueVals:
    tempArr = np.zeros([rows, cols])       #initialize a temporary numpy Array for storing the binary rasters within the loop
    arcpy.AddMessage('Creating binary raster of class ' + str(val))
    for index, x in np.ndenumerate(myArray):
        if val != x:
            tempArr[index] = None
        else:
            tempArr[index] = val
        rastDict["Class value is: #" + str(val)] = tempArr	

arcpy.AddMessage(rastDict)

      
#This line works, but I need to find out how to pass my parameter values
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", extent=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", sample=1000, out=\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points7.shp\", mindist=100);');


#Doesn't Work
#subp.call(GME_file -c \genrandompnts(raster=inputraster, extent=input_raster, sample=numpoints, out=output_path, mindist=min_dist);



