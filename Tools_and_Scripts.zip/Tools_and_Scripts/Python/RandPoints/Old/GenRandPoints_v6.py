# GenRandPoints_v6.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-07-03
# Creator:  Roy D. Gilb
#
# Summary: 
#   Creates a specified number of random sample point features on an input raster image. A set number of random points can be 
#   generated for each cover class of the input raster. 
#     
# Usage Tips:   
#  * This script expects a raster dataset that has cover class values (such as NLCD data). The tool will not run on an unclassified raster.
#  * This script will not not process a raster that is too large. 
#  * This script uses a subprocess call to the Geospatial Modelling Environment (GME) interface  in order to create random points in 
#    a stratified manner using the genrandpnts() command.
#  * The number of sample points parameter acts as a the number of random points to generate WITHIN EACH COVER class. If there are 14 cover classes 
#    (like NLCD raster data) and the user specifies 100 sample points, then 1400 points will be created, given the contraints are not too extreme.
#  * When running this script, the user will see the Geospatial Modelling Environment open up and an error prompt will appear. Simply click
#    'Ok' at the error prompt and the script will continue. This is an unresolved minor bug.
#  * This script produces many output files in order to run the GME command, all of which are created and stored in the user-defined output path. 
#    These output files include:
#       ->One binary raster dataset for each cover class in the input raster; composed of real pixels for the one cover class and NoData values everywhere else.
#           -->For use by the GME command to generate stratified random points 
#       ->One text file that contains static text commands to be read by the GME interface 
#       ->One corresponding shapefile for each cover class that contains the randomly generated points only on the current cover class's pixels
#           -->For use at the end of the script to merge all of these shapefiles together for the final output shapefile
#  * This script expects the Geospatial Modelling Environment executable file to be stored in the following directory: 'C:\Software\SEGME.exe'.
#    The directory structure MUST match exactly in order for this script to run successfully.
#  * The user must be careful whesn entering inputs, especially with the minimum distance and excluded polygon parameters. If there is too large of a 
#    minimum distance or excluded polygon input and too few cover class pixels, then GME will create as many points as possible within the constraints
#    and may possibly enter an infinite loop.
#
# Syntax:
#   GEN_RAND_POINTS(<inRastText>, <numPoints>, <outputPath>, {minDistance}, {excludedClass})
#
# Required Arguments:
#   inRastText: The raster dataset input by user which is used for both distributing the points over classes and the spatial extent 
#   numPoints: The number of random points to generate WITHIN EACH COVER CLASS (see usage tips).
#   outputPath: The directory to store all of the script's outputs, including the final points shapefile.
#   minDistance: (Optional) - If specified, points are prevented from being generated within this minimum distance of each other. 
#                             This option can be dangerous (see last usage tip).
#   excludedClass: (Optional) - The polygon data source containing exculding polygons; points will not be generated within these polygons. 
#                               This option can be dangerous (see last usage tip).

# Temporary feature classes:

# Spatial reference objects:
#   mySR_Rast:  Spatial reference of inRastText
#   mySR_Excl:  Spatial reference of excludedClass

# Other local variables:
#   myRoot: The root working/output directory for the script
#   inRaster: A raster object of the input raster (which was originally passed in as a text parameter
#   myArray: A numpyarray containing values of the input raster (used for extracting the uniqe class values)
#   UniqueVals: List of unique values that correspond to each of the input raster's cover classes. Used for creating unique binary rasters
#

# -------------------------------------------------------------------------------------------------------

#Import required modules
import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

#Set workspace variables
myRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints'

arcpy.env.workspace = myRoot            #Set workspace

#Parameters passed in from arc tool
inRastText = arcpy.GetParameterAsText(0)
numPoints = arcpy.GetParameterAsText(1)
outputPath = arcpy.GetParameterAsText(2)
minDistance = arcpy.GetParameterAsText(3)
excludedClass = arcpy.GetParameterAsText(4)

#Local variables
inRaster = Raster(inRastText)                   #Create raster variable from parameter input text
myArray = arcpy.RasterToNumPyArray(inRastText)  #Create a numpyarray of the input raster for extracting unique values
uniqueVals = np.unique(myArray)                 #Extract unique values


#Check to make sure input data have spatial reference defined and matching; if not then exit 
arcpy.AddMessage("Checking spatial references...")
print "Checking spatial references..."

#Get spatial references for each input raster or shapefile (if included)
mySR_Rast = arcpy.Describe(inRastText).spatialReference.name
if excludedClass:
    mySR_Excl = arcpy.Describe(excludedClass).spatialReference.name

#Check Spatial References 
if mySR_Rast == "Unknown":
   arcpy.AddError("Your input raster has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different feature class.")
   arcpy.AddError("Then try this tool again.")

elif excludedClass and mySR_Excl == "Unknown":
   arcpy.AddError("Your exlcluded class shapefile has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different shapefile.")
   arcpy.AddError("Then try this tool again.")

elif excludedClass and mySR_Rast != mySR_Excl:
   arcpy.AddError("The spatial references of your input data do not match.")
   arcpy.AddError("Please select input data with exactly matching spatial references.")
   arcpy.AddError("Then try this tool again.")

#Assuming input data have spatial references defined and matching, proceed...
else:

    #Binary Raster Loops
    os.chdir(outputPath)  #Change directory to the folder to store the rasters
    
    #Print informative messages for user
    arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))
    print('Unique class values are: ' + str(uniqueVals))
    arcpy.AddMessage('Beginning binary raster creation')
    print('Beginning binary raster creation')
    
    
    textFile = open("GME_SCRIPT.txt", "w")  
     
    #Loops to create a binary raster for each feature class in the input raster (should be a total of 14 binary rasters for NLCD data)
    for val in uniqueVals:
        arcpy.AddMessage('Creating binary raster of class ' + str(val))     #Give user some processing feedback
        print('Creating binary raster of class ' + str(val)) 
       
        #Create a variable for the path/name of the unique binary rasters based on their value
        binRasterPath = outputPath + "\\binaryClass"
        binRasterPath = binRasterPath + str(val)
       
        #Use a conditional statement to extract just the values within the raster that match the unique class value for the iteration
        outRaster = Con((inRaster == int(val)), 1)       
        outRaster.save(binRasterPath)                   #Save a binary raster with either 1 or NoData for each class value
        
        
        #Check for the optional minimum distance and excluded class parameters
        #Within each if statement --> creates properly formatted string for running GME genrandompnts command and write that string to a unique txt file
        if minDistance and excludedClass:             #Condition with both minDistance and excluded class as optional paramters input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "mindist=" + str(minDistance) + ", excl=\"" + str(excludedClass) + "\", " + "pnd=TRUE);"
            
        elif minDistance and not excludedClass:       #Condition with minDistance as the only optional paramter input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "mindist=" + str(minDistance) + ", pnd=TRUE);"
        
        elif excludedClass and not minDistance:       #Condition with excludedClass as the only optional parameter input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "excl=\"" + str(excludedClass) + "\", " + "pnd=TRUE);"
        
        else:               #Condition without minimum distance or excluded class as parameters               
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "pnd=TRUE);"
        
        #Create and write to txt files for processing in GME
        textFile.write(myInfo + "\n")                                      #Populate the txt file with a GME command, one on each line
     
    #Close the textFile for writing 
    textFile.close()   
    
    
    try:
    #Walk through all files and directories staring with the root (outputPath)
       for root, dirs, myFiles in os.walk(outputPath):
          for filename in myFiles: 
             if filename.endswith(".txt"): #Find the file that ends with .txt (the GME script file)
                #User feedback
                arcpy.AddMessage("Running file: " + filename)
                print("Running file: " + filename)
             
                #Properly format the GME call as a string and use subprocess.call to run the GME script from within each txt file
                gmeCall = r'C:\Software\SEGME.exe -c run(in=\"' + outputPath + '\\' + filename + '\\");'       #\");');        #[11: filename.find('.txt')] + '.txt\\'");"     
                

    #Error handling
    except IOError:
       arcpy.AddMessage("Error: can\'t find file or read data.")
    else:
       arcpy.AddMessage("Successfully created GME scripts.")

    arcpy.AddMessage('Your GME call is: ' + gmeCall)   
    
    #Finally call the GME script text file with subp.call to create a shapefile for each cover class
    subp.call(gmeCall);
    
    
    #Create new fields in shapefiles to keep original class values 
    #Merge shapefiles into one while retaining class values from raster    
        
    #Merge shapefiles
    arcpy.AddMessage("Merging binary point shapefiles...")      #Inform user of processes
    print("Merging binary point shapefiles...")
    
    tmp = "binaryClass"
    os.chdir(outputPath)
    arcpy.env.workspace = outputPath

    #Get a list of all the shapefiles containing random sample points on each raster class value
    fcs = arcpy.ListFeatureClasses()

    for fc in fcs:
      tmpVal = fc[11: fc.find('.shp')]      #Substring call on the feature classes filename to extract the original class number
      arcpy.AddField_management(fc, 'CLASSVALUE','text')    #Add a field called CLASSVALUE
      arcpy.CalculateField_management(fc, 'CLASSVALUE', '"'+tmpVal+'"')
    arcpy.Merge_management(fcs, 'randPointsOut.shp')           #Final output product                             #Code idea from http://gis.stackexchange.com/questions/7007/batch-shapefile-merge-with-adding-and-calculating-field
        
     
     
     
    #ADD BUFFER TO POINTS ???

    #CALL PAIRED SAMPLE POINT SUBROUTINE  ???
     