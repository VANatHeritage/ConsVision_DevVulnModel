# GenRandPoints_v5.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-07-02
# Creator:  Roy D. Gilb
#
# Summary: Creates a specified number of random sample point features on an input raster image. A set number of random points can be 
# generated for each cover class of the input raster. 
#     
# Usage Tips:
#     
#   *This script uses a subprocess call to the Geospatial Modelling Environment interface  in order to create random points in 
#    a stratified manner using the genrandpnts() command.
#
#   *This script produces many output files in order to run the GME command, all of which are created and stored in the user-defined output path. 
#   *These output files include:
#       ->One binary raster dataset for each cover class in the input raster; composed of real pixels for the one cover class and NoData values everywhere else.
#           -->For use by the GME command to generate stratified random points 
#       ->One corresponding text file for each cover class in the input raster; 
#           -->For storing the static text commands passed to the GME interface
#       ->One corresponding shapefile for each cover class that contains the randomly generated points only on the current cover class's pixels
#           -->For use at the end of the script to merge all of these shapefiles together for the final output shapefile
#
#   *This script expects the Geospatial Modelling Environment executable file to be stored in the following directory: 'C:\Software\SEGME.exe'.
#    The directory structure MUST match exactly in order for this script to run successfully.
#
# Syntax:

# Required Arguments:
#
#  *inRastText: the intended 
#  *numPoints
#  *outputPath
#  *minDistance
#  *excludedClass


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

#Set workspace variables
myRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints'
binRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters'

arcpy.env.workspace = myRoot            #Set workspace

#Parameters passed in from arc tool
inRastText = arcpy.GetParameterAsText(0)
numPoints = arcpy.GetParameterAsText(1)
outputPath = arcpy.GetParameterAsText(2)
minDistance = arcpy.GetParameterAsText(3)
excludedClass = arcpy.GetParameterAsText(4)

#Local variables
GME_file = 'C:\Software\SEGME.exe'              #Not used
inRaster = Raster(inRastText)                   #Create raster variable from parameter input text
myArray = arcpy.RasterToNumPyArray(inRastText)  #Create a numpyarray of the input raster for extracting unique values
uniqueVals = np.unique(myArray)                 #Extract unique values
count = 1                                       #For indexing and giving user feedback


#Check to make sure input data have spatial reference defined and matching; if not then exit 
arcpy.AddMessage("Checking spatial references...")
print "Checking spatial references..."

#Get spatial references for each input raster or shapefile (if included)
mySR_Rast = arcpy.Describe(inRastText).spatialReference.name
if excludedClass:
    mySR_Excl = arcpy.Describe(excludedClass).spatialReference.name

#Check Spatial References 
if mySR_Rast == "Unknown":
   arcpy.AddError("Your input raster has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different feature class.")
   arcpy.AddError("Then try this tool again.")

elif excludedClass and mySR_Excl == "Unknown":
   arcpy.AddError("Your exlcluded class shapefile has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different shapefile.")
   arcpy.AddError("Then try this tool again.")

elif excludedClass and mySR_Rast != mySR_Excl:
   arcpy.AddError("The spatial references of your input data do not match.")
   arcpy.AddError("Please select input data with exactly matching spatial references.")
   arcpy.AddError("Then try this tool again.")

#Assuming input data have spatial references defined and matching, proceed...
else:

    #Binary Raster Loops
    os.chdir(outputPath)  #Change directory to the folder to store the rasters
    
    #Print informative messages for user
    arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))
    print('Unique class values are: ' + str(uniqueVals))
    arcpy.AddMessage('Beginning binary raster creation')
    print('Beginning binary raster creation')
        
    #Loops to create a binary raster for each feature class in the input raster (should be a total of 14 binary rasters for NLCD data)
    for val in uniqueVals:
        arcpy.AddMessage('Creating binary raster of class ' + str(val))     #Give user some processing feedback
        print('Creating binary raster of class ' + str(val)) 
       
        #Create a variable for the path/name of the unique binary rasters based on their value
        binRasterPath = outputPath + "\\binaryClass"
        binRasterPath = binRasterPath + str(val)
       
        #Use a conditional statement to extract just the values within the raster that match the unique class value for the iteration
        outRaster = Con((inRaster == int(val)), 1)       
        outRaster.save(binRasterPath)                   #Save a binary raster with either 1 or NoData for each class value
        
        
        #Check for the optional minimum distance and excluded class parameters
        #Within each if statement --> creates properly formatted string for running GME genrandompnts command and write that string to a unique txt file
        if minDistance and excludedClass:             #Condition with both minDistance and excluded class as optional paramters input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "mindist=" + str(minDistance) + ", excl=\"" + str(excludedClass) + "\", " + "pnd=TRUE);"
            
        elif minDistance and not excludedClass:       #Condition with minDistance as the only optional paramter input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "mindist=" + str(minDistance) + ", pnd=TRUE);"
        
        elif excludedClass and not minDistance:       #Condition with excludedClass as the only optional parameter input by user
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "excl=\"" + str(excludedClass) + "\", " + "pnd=TRUE);"
        
        else:               #Condition without minimum distance or excluded class as parameters               
            myInfo = "genrandompnts(raster=\"" + str(outRaster) + "\", "  + "extent=\"" + str(outRaster) + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\\binaryClass" + str(val) + ".shp" + "\", " + "pnd=TRUE);"
        
        #Create and write to txt files for processing in GME
        textFile = open("binaryClass" + str(val) + ".txt", "w")
        textFile.write(myInfo)                                      #Populate the txt file with a GME command 
        textFile.close()
       
    
    
    try:
    #Recursively walk through all files and directories staring with the root (outputPath)
       for root, dirs, myFiles in os.walk(outputPath):
          for filename in myFiles: 
             if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
                #Change current directory to the directory referenced by walk (contains txt files)
                os.chdir(outputPath)
                
                #Properly format the GME call as a string and use subprocess.call to run the GME script from within each txt file
                gmeCall = r'C:\\Software\\SEGME.exe -c run(in=\"' + outputPath + "\"" + '\\' + filename + '\\");'       #\");');        #[11: filename.find('.txt')] + '.txt\\'");"
                subp.call(gmeCall);             #subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\");');
                
                #User feedback
                arcpy.AddMessage((str(count) + ") Running file: " + filename))
                count = count + 1
                

    #Error handling
    except IOError:
       arcpy.AddMessage("Error: can\'t find file or read data.")
    else:
       arcpy.AddMessage("Successfully ran GME scripts.")

      
    #Create new fields in shpfiles to keep original class values 
    #Merge shapefiles into one whiel retaining class values from raster    
        

    #Merge shapefiles
    tmp = "binaryClass"
    os.chdir(outputPath)
    arcpy.env.workspace = outputPath

    #Get a list of all the shapefiles containing random sample points on each raster class value
    fcs = arcpy.ListFeatureClasses()

    for fc in fcs:
      tmpVal = fc[11: fc.find('.shp')]      #Substring call on the feature classes filename to extract the original class number
      arcpy.AddField_management(fc, 'CLASSVALUE','text')    #Add a field called CLASSVALUE
      arcpy.CalculateField_management(fc, 'CLASSVALUE', '"'+tmpVal+'"')
    arcpy.Merge_management(fcs, 'randPointsOut.shp')           #Final output product                             #Code idea from http://gis.stackexchange.com/questions/7007/batch-shapefile-merge-with-adding-and-calculating-field
        
     
     
     
    #ADD BUFFER TO POINTS ???

    #CALL PAIRED SAMPLE POINT SUBROUTINE  ???
     