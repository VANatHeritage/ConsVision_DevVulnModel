# ----------------------------------------------------------------------------------------
# CreateRule8SBB.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2013-06-20
# Last Edit: 2016-02-01
# Creator:  Kirsten R. Hazler
#
# Summary:
#     Creates Rule 8 Site Building Blocks (SBBs) from Procedural Features (PFs).  
#     Carries out the following general procedures:
#     1.  Buffer the PF by 250-m.  This is the minimum buffer.
#     2.  Buffer the PF by 500-m.  This is the maximum buffer.
#     3.  Delineate the catchment of the PF.
#     4.  Merge the minimum buffer with the delineated catchment.
#     5.  Clip the merged feature to the maximum buffer.
#
# Usage Tips:
#     *  This script accepts a shapefile or geodatabase feature classes as inputs for the 
#        Procedural Features.
#     *  This script does not test to determine if all of the input Procedural Features 
#        should be subject to Rule 8. The user must ensure that this is so.
#     *  It is recommended that the flow direction raster be stored on your local drive 
#        rather than a network drive, to optimize processing speed.
#     *  This script is designed to send all output to a feature class within a 
#        geodatabase. It has not been tested for output to shapefiles.
#     *  For best results, it is recommended that you close all other programs before 
#        running this tool, since it relies on having ample memory for processing.
#     *  Due to a bug in ArcGIS, you MUST make sure that your current and scratch 
#        workspaces, as set in ArcCatalog or ArcMap, are valid.  Regardless of what you 
#        input as the workspace for the run of this tool, the Watershed process uses the 
#        workspace set in ArcGIS.  You can set the workspace under
#        Geoprocessing/Environments/Workspace. [This may or may not still be true in the 
#        current version of ArcGIS, but leaving this note for posterity.]
#
# Syntax:  CreateRule8SBB_sbbTools(Input_PF, Input_SFID, Input_FDIR, Output_SBB, Out_Fails)
# ----------------------------------------------------------------------------------------
ScriptDate = '2016-02-01' # Used for informative message down below

# Import required modules
import arcpy # provides access to all ArcGIS geoprocessing functions
import os # provides access to operating system funtionality 
import sys # provides access to Python system functions
import traceback # used for error handling
import math
import csv # provides ability to write rows to a text file
import gc # garbage collection
from datetime import datetime as dt # for timestamping

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

# outScratch = arcpy.env.scratchGDB # Use this for trouble-shooting only
# arcpy.AddMessage('Scratch products will be stored in %s' % outScratch)
outScratch = "in_memory"

# Required arguments to be input by user...
Input_PF = arcpy.GetParameterAsText(0) 
   # An input feature class or feature layer representing Procedural Features
Input_SFID = arcpy.GetParameterAsText(1) 
   # The name of the field containing the unique source feature ID
Input_FDIR = arcpy.GetParameterAsText(2) 
   # An input raster representing flow direction (derived from digital elevation model) 
Output_SBB = arcpy.GetParameterAsText(3) 
   # An output feature class representing Site Building Blocks

# Declare some additional parameters
# These can be tweaked as desired
tinyBuff = 7 # amount to buffer tiny features so they can be rasterized
minBuff = 250 # minimum buffer to include in SBB
maxBuff = 500 # maximum buffer to include in SBB
procBuff = 750 # buffer to specify processing extent

# Create an empty list to store IDs of features that fail to get processed
myFailList = []

# Declare path/name of output data and workspace
drive, path = os.path.splitdrive(Output_SBB) 
path, filename = os.path.split(path)
myWorkspace = drive + os.sep + path
myFolder = os.path.abspath(os.path.join(myWorkspace,".."))
Output_SBB_fname = filename
ts = dt.now().strftime("%Y%m%d_%H%M%S") # timestamp
myFailLog = myFolder + os.sep + 'FailLog56_%s' % ts 
   # text file storing features that fail to get processed

# Set environmental variables
arcpy.env.workspace = myWorkspace # Set the workspace for geoprocessing
arcpy.env.scratchWorkspace = outScratch # Set the scratch workspace for geoprocessing
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = Input_FDIR # Set the snap raster for proper alignment 
arcpy.env.outputCoordinateSystem = "PROJCS['NAD_1983_Virginia_Lambert',GEOGCS['GCS_North_American_1983',DATUM['D_North_American_1983',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Lambert_Conformal_Conic'],PARAMETER['False_Easting',0.0],PARAMETER['False_Northing',0.0],PARAMETER['Central_Meridian',-79.5],PARAMETER['Standard_Parallel_1',37.0],PARAMETER['Standard_Parallel_2',39.5],PARAMETER['Latitude_Of_Origin',36.0],UNIT['Meter',1.0],AUTHORITY['EPSG',3968]]"

# Check to make sure input data have spatial reference defined and matching; if not then
# exit gracefully.
# Part of this has been commented out for now, so it does NOT enforce projection match.
arcpy.AddMessage("Checking spatial references...")
mySR_PF = arcpy.Describe(Input_PF).spatialReference.name
mySR_FDIR = arcpy.Describe(Input_FDIR).spatialReference.name

if mySR_PF == "Unknown":
   arcpy.AddError("Your Procedural Features feature class has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different feature class.")
   arcpy.AddError("Then try this tool again.")

elif mySR_FDIR == "Unknown":
   arcpy.AddError("Your flow direction raster has no defined spatial reference.")
   arcpy.AddError("Please define the spatial reference of your data or select a different raster.")
   arcpy.AddError("Then try this tool again.")

# elif mySR_PF != mySR_FDIR:
   # arcpy.AddError("The spatial references of your input data do not match.")
   # arcpy.AddError("Please select input data with exactly matching spatial references.")
   # arcpy.AddError("Then try this tool again.")

# Assuming input data have spatial references defined and matching, proceed...
else:
   try:   
      # Print helpful messages to geoprocessing window
      arcpy.AddMessage("Your input feature class is " + Input_PF)
      arcpy.AddMessage("Your flow direction raster is " + Input_FDIR)
      arcpy.AddMessage("Your output dataset is " + Output_SBB)
      arcpy.AddMessage("The running script was last edited %s" % ScriptDate)
      
      # Process:  Create Feature Class (Data Management)
      # Create a feature class to store SBBs
      arcpy.AddMessage("Creating Site Building Blocks feature class for Rule 8...")
      arcpy.CreateFeatureclass_management (myWorkspace, Output_SBB_fname, "POLYGON", Input_PF, "", "", Input_PF)

      # Loop through the individual Procedural Features
      myProcFeats = arcpy.da.SearchCursor(Input_PF, [Input_SFID]) # Get the set of features
      myIndex = 1 # Set a counter index

      for myPF in myProcFeats: 
      # for each Procedural Feature in the set, do the following...
         try: # Even if one feature fails, script can proceed to next feature
            # Extract the unique Source Feature ID
            myID = myPF[0]

            # Add a progress message
            arcpy.AddMessage("\nWorking on Rule 8 feature " + str(myIndex))
            arcpy.AddMessage("Selecting Procedural Feature where Source Feature ID = " + str(int(myID)) + "...")

            # Reset processing extent, because ArcGIS is stupid.
            myExtent = str(arcpy.Describe(Input_FDIR).extent).replace(" NaN", "")
            arcpy.env.extent = myExtent
            
            # Process:  Select (Analysis)
            # Create a temporary feature class including only the current PF
            myCurrentPF = outScratch + os.sep + "tmpProceduralFeature"
            myWhereClause_PF = '"' + Input_SFID + '" = ' + str(int(myID))
            arcpy.Select_analysis (Input_PF, myCurrentPF, myWhereClause_PF)

            # Process:  Remove Spatial Index (Data Management)
            # Remove the spatial index to avoid potential conflicts when updating feature.
            # This step is necessary because ArcGIS is stupid.
            # This is put in a TRY block b/c not applicable to all file types.
            try:
               arcpy.RemoveSpatialIndex_management(myCurrentPF)
               arcpy.AddMessage("Removing spatial index from Procedural Feature data")
            except:
               pass
             
            # Process:  Buffer (Analysis)
            # Step 1: Create a minimum buffer around the Procedural Feature
            arcpy.AddMessage("Creating minimum buffer")
            myMinBuffer = outScratch + os.sep + "minBuff"
            arcpy.Buffer_analysis (myCurrentPF, myMinBuffer, minBuff, "", "", "", "")  
            feats2merge = [myMinBuffer]          
               
            # Process:  Buffer (Analysis)
            # Step 2: Create a maximum buffer around the Procedural Feature
            myMaxBuffer = outScratch + os.sep + "maxBuff"
            arcpy.AddMessage("Creating maximum buffer")
            arcpy.Buffer_analysis (myCurrentPF, myMaxBuffer, maxBuff, "", "", "", "")

            # Process:  Buffer (Analysis)
            # Set the processing extent
            arcpy.AddMessage("Creating processing buffer...")
            myProcBuffer = outScratch + os.sep + "procBuff"
            arcpy.Buffer_analysis (myCurrentPF, myProcBuffer, procBuff, "", "", "", "")
            myExtent = str(arcpy.Describe(myProcBuffer).extent).replace(" NaN", "")
            arcpy.env.extent = myExtent 
               # Necessary to specify the extent because ArcGIS is stupid. 

            # Process:  Minimum Bounding Geometry
            # This is done to identify features that are too narrow to be rasterized.
            myRect = outScratch + os.sep + "tmpRect"
            arcpy.MinimumBoundingGeometry_management(myCurrentPF,myRect,"RECTANGLE_BY_WIDTH","NONE","#","MBG_FIELDS")
            # Extract the width of the minimum bounding rectangle
            myRects = arcpy.da.SearchCursor(myRect, "MBG_Width") 
            rectWidth = (myRects.next())[0]

            # Process: Feature to Raster (Conversion)
            # Converts the current Procedural Feature to a rasterized representation
            myPF_Raster = outScratch + os.sep + "tmpPF_Raster"
            if rectWidth < 15:
            # Check for feature width and buffer before conversion if too small
               arcpy.AddMessage("Buffering PF by small amount because it's too narrow to rasterize")
               myTinyBuffer = outScratch + os.sep + "tmpBuff5"
               arcpy.Buffer_analysis (myCurrentPF, myTinyBuffer, tinyBuff, "", "", "", "")
               arcpy.AddMessage("Converting buffered PF to raster...")
               arcpy.FeatureToRaster_conversion (myTinyBuffer, Input_SFID, myPF_Raster, 10)
            else:
               arcpy.AddMessage("Converting PF to raster...")
               arcpy.FeatureToRaster_conversion (myCurrentPF, Input_SFID, myPF_Raster, 10)
            
            # Process:  Clip (Data Management)
            # Clips the input raster to the processing buffer 
            myClip_FDIR = outScratch + os.sep + "tmpClip_FDIR"
            arcpy.AddMessage("Clipping flow direction raster...")
            arcpy.Clip_management(Input_FDIR, myExtent, myClip_FDIR, myProcBuffer, "", "ClippingGeometry")

            # Process: Watershed (Spatial Analyst)
            # Step 3: Delineate the catchment of the PF
            arcpy.AddMessage("Determining contributing area...")
            myExtent = str(arcpy.Describe(myProcBuffer).extent).replace(" NaN", "")
            arcpy.env.extent = myExtent #Limit processing extent to 1000-m around feature.
            myWatershed = Watershed(myClip_FDIR, myPF_Raster)
            myWatershed.save(outScratch + os.sep + "tmpWatershed")
            
            # Process: Raster to Polygon (Conversion)
            # Converts the contributing area back to a vectorized representation
            arcpy.AddMessage("Converting contributing area to polygon...")
            myVectorWS = outScratch + os.sep + "tmpVWatershed"
            arcpy.RasterToPolygon_conversion (myWatershed, myVectorWS, "SIMPLIFY", "")

            # Reset processing extent, because ArcGIS is stupid.
            myExtent = str(arcpy.Describe(Input_FDIR).extent).replace(" NaN", "")
            arcpy.env.extent = myExtent
            
            # Process:  Merge (Data Management)
            # Step 4: Merged the minimum buffer with the catchment
            feats2merge = [myMinBuffer, myVectorWS]
            myMergeFeats = outScratch + os.sep + "tmpMergeFeats"
            arcpy.Merge_management (feats2merge, myMergeFeats, "")

            # Process:  Dissolve (Data Management)
            # Dissolve features into a single polygon
            myDissFeats = outScratch + os.sep + "tmpDissolvedFeatures"
            arcpy.AddMessage("Dissolving features into one...")
            arcpy.Dissolve_management (myMergeFeats, myDissFeats, "", "", "", "")
         
            # Process:  Clip (Analysis)
            # Step 5: Clip the merged feature to the maximum buffer
            myClipFeat = outScratch + os.sep + "tmpClipFeature"
            arcpy.AddMessage("Clipping to maximum buffer...")
            arcpy.Clip_analysis(myDissFeats, myMaxBuffer, myClipFeat, "")
            
            # Update the feature with its final shape
            myFinalShape = arcpy.SearchCursor(myClipFeat).next().Shape 
            myCurrentPF_rows = arcpy.UpdateCursor(myCurrentPF, "", "", "Shape", "")
            myPF_row = myCurrentPF_rows.next()
            myPF_row.Shape = myFinalShape
            myCurrentPF_rows.updateRow(myPF_row) 
            
            # Process:  Append
            # Append the final geometry to the SBB feature class.
            arcpy.AddMessage("Appending feature...")
            arcpy.Append_management(myCurrentPF, Output_SBB, "NO_TEST", "", "")

            # Add final progress message
            arcpy.AddMessage("Finished processing feature " + str(myIndex))   

         except:       
            # Add failure message and append failed feature ID to list
            arcpy.AddMessage("\nFailed to fully process feature " + str(myIndex))
            myFailList.append(int(myID))

            # Error handling code swiped from "A Python Primer for ArcGIS"
            tb = sys.exc_info()[2]
            tbinfo = traceback.format_tb(tb)[0]
            pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
            msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

            arcpy.AddWarning(msgs)
            arcpy.AddWarning(pymsg)
            arcpy.AddMessage(arcpy.GetMessages(1))

            # Add status message
            arcpy.AddMessage("\nMoving on to the next feature.  Note that the SBB output will be incomplete.")  
            
         finally:
            # Increment the index by one and clear memory before returning to beginning of the loop
            myIndex += 1 
            try:
               arcpy.Delete_management(outScratch)
            except:
               pass
            if myPF:
               del myPF
            if arcpy.Exists("myWatershed"):
               arcpy.Delete_management("myWatershed")
            GarbageObjects = gc.collect()
   
      # Once the script as a whole has succeeded, let the user know if any individual 
      # features failed
      if len(myFailList) == 0:
         arcpy.AddMessage("All features successfully processed")
      else:
         arcpy.AddWarning("Processing failed for the following features: " + str(myFailList))
         arcpy.AddWarning("See the log file " + myFailLog)
         with open(myFailLog, 'wb') as csvfile:
            myCSV = csv.writer(csvfile)
            for value in myFailList:
               myCSV.writerow([value])
   
   # This code block determines what happens if the "try" code block fails
   except:
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))
    
   # Additional code to run regardless of whether the script succeeds or not
   finally:  
      arcpy.AddMessage("Done processing Rule 8 features")








