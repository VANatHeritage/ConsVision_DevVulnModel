# ------------------------------------------------------------------------------------------
# Build_Mask_From_Img.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-11-22
# Last Edit:  2013-11-22
# Creator:  Kirsten R. Hazler
#
# Summary:
#     This script is a wrapper for IDL code which does the actual processing.  It iterates through all
#     files contained within the designated input directory and all its subdirectories, creating binary
#     masks based on the specified NoData value (= data ignore value).
#
#  Usage Tips:
#     (1) For multi-band images, this script assumes that the locations of the first band's NoData 
#     values are representative for all bands (that is, the mask is based entirely on the first
#     band.)
#     (2) This tool was developed to work with Landsat-derived files following a naming convention
#     where the first 5 characters (digits) in the source file name indicate the Landsat path/row.
#     These first 5 characters are used to name the corrseponding output masks.
#
# Required Arguments:
#     mySrcDir:  the directory containing source image files
#     myMskDir:  the directory to contain the output mask files
#     NoDataVal:  the number value representing "NoData" in the source images
# ------------------------------------------------------------------------------------------

# Import required standard modules
import envipy, os, os.path as path, sys, traceback, datetime, re, Tkinter, tkFileDialog
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta, CreateMetaDict as MetaDict

# Declare a timestamp variable
timestamp = datetime.datetime.now()

# Prepare dialog - Tkinter gobblety-gook
# Make a top-level instance and hide since it is ugly and big.
root = Tkinter.Tk()
root.withdraw()

# Make it almost invisible - no decorations, 0 size, top left corner.
root.overrideredirect(True)
root.geometry('0x0+0+0')

# Show window again and lift it to top so it can get focus,
# otherwise dialogs will end up behind the terminal.
root.deiconify()
root.lift()
root.focus_force()

# Script arguments enter by user at prompts
mySrcDir = tkFileDialog.askdirectory(parent=root,initialdir="D:\",
                                     title='Choose directory containing source images')
myMskDir = tkFileDialog.askdirectory(parent=root,initialdir="D:\",
                                     title='Choose directory to store output mask images')
NoDataVal = raw_input('Enter a NoData value:\n')

# Create variables to reference the IDL script
mytool = 'Build_Mask_From_Img'
mytoolpath = r'..\IDL\Build_Mask_From_Img.sav'

# Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
          for dirpath, dirnames, files in os.walk(mySrcDir)
          for f in files if f.endswith('.dat')]

# Create and open a log file to write processing records
mylogfile = "MaskBuild_log.txt"
mylogfile = myMskDir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Mask Build Processing Log" + "\n" + "\n")
mylog.write("Source image directory: " + mySrcDir + "\n")
mylog.write("Directory to store output mask images: " + myMskDir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")          
 
# Loop through the image set
for SrcImg in mySrcImgs:

   try:
      print "Working on " + SrcImg
      
      # Get the path/row ID from the SrcImg name
      myPathRow = SrcImg[0:5]
      
      # Declare the output file path
      MskImg = myMskDir + path.sep + myPathRow + '_MSK.dat'
      
      # Run the IDL script
      print "Running IDL script"
      envipy.RunTool(mytool, SrcImg, MskImg, NoDataVal, Library = mytoolpath)
      
      # Then do other text-processing cleanup with the header
      
      #Confirmation of successful processing
      print "Successfully processed " + SrcImg
      mylog.write("Successfully processed " + SrcImg + "\n")

   except:
      mylog.write("Failed to build mask for " + SrcImg + "\n")
      
      # Error handling code modified from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      print pymsg
      print "Mask Build failed for " + SrcImg

print "Processing Complete"
print "For details, see the log file 'MaskBuild_log.txt' in your output directory"

# Update the timestamp
timestamp = datetime.datetime.now()
mylog.write("Program execution completed at " + str(timestamp) + "\n")      
mylog.close()