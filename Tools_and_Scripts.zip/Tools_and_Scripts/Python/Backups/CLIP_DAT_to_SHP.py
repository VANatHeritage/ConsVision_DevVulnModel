# ----------------------------------------------------------------------------------------------
# CLIP_DAT_by_SHP.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date: 2013-10-24
# Last Edit: 2013-11-7
# Creator: Kirsten R. Hazler
#
# Summary:  
#     Clips all Landsat5-TM images (ENVI *.dat format) within a specified directory (including 
#     subdirectories) to their corresponding footprints which are defined by shapefiles (*.shp).  
#     This script matches the images to the correct vector files via a 5-digit Landsat path/row 
#     identifier.  This routine was developed to work with files that follow a very specific naming 
#     convention.  This script has limited error handling, and will fail or yield incorrect results
#     if the naming convention is not followed (see usage tips). 
#
# Usage Tips:
#     (1) This script will only work if both images and shapefiles are named according to a regular
#     convention, such that the path/row are identified in the names and images can be matched
#     to the correct footprint.  Each shapefile should contain only a single footprint polygon.
#     (2) Check the log file "CLIP_LOG.txt" which is generated in the image output directory.  The
#     log file contains a record of all files processed.
#
# Required Arguments:
#     mySrcDir: Directory containing source images to be clipped
#     myVecDir: Directory containing vector files (EVF format) defining the areas to clip
#     myMaskDir: Directory that contains or will contain mask images derived from EVF files
#     myClipDir: Directory to contain output clipped/masked images
# ----------------------------------------------------------------------------------------------

# Import required modules
import envipy, arcpy, os, os.path, sys, traceback 

# Script arguments hard-coded
mySrcDir = r'D:\VulnerabilityModel\Testing\MaskClipTest\SrcDir'
myVecDir = r'D:\VulnerabilityModel\Testing\MaskClipTest\VecDir'
myMaskDir = r'D:\VulnerabilityModel\Testing\MaskClipTest\MaskDir'
myClipDir = r'D:\VulnerabilityModel\Testing\MaskClipTest\ClipDir'

## Script arguments to be input by user when run through ArcGIS tool
#mySrcDir = arcpy.GetParameterAsText(0)
#myVecDir = arcpy.GetParameterAsText(1)
#myMaskDir = arcpy.GetParameterAsText(2)
#myClipDir = arcpy.GetParameterAsText(3)

#Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(mySrcDir)
             for f in files if f.endswith('.dat')]

#Set the string that will need to be added back to metadata for thermal images
#These are specific to Landsat TM; different values are needed for ETM+ data.
thermal_string = 'thermal k1 = 607.760000' + '\n' + 'thermal k2 = 1260.560000'

#Loop through the image set
for Img in mySrcImgs:
   try:
      print Img
         
                    

   
   except:
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))

      print msgs
      print pymsg
      print arcpy.AddMessage(arcpy.GetMessages(1))
   



