# ----------------------------------------------------------------------------------------------
# CLIPMASK_GRID_by_SHP.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-12-05
# Last Edit: 2013-12-05
# Creator: Kirsten R. Hazler
#
# Summary:  
#     Clips a large NLCD grid (or other raster in GRID format) to a set of WRS footprint shapefiles, 
#     outputting a separate subset raster for each shapefile. 
#
# Usage Tips:
#     A specific naming convention for shapefiles is required for this script to run correctly.
#     Shapefiles should be named SideBuff#####.shp, where ##### signifies the path/row of the
#     footprint
#
#     The script should be run
#
#     Check the log file "CLIP_LOG.txt" which is generated in the image output directory.  The
#     log file will contain a record of all files processed (or failed to process).
#
# Required Arguments:
#     srcGRID: The GRID to be subsetted
#     ShpDir: Directory containing shapefiles defining the areas to clip
#     ClipDir: Directory to contain output clipped/masked images
# ----------------------------------------------------------------------------------------------

# Import required standard modules
import arcpy, os, os.path as path, sys, traceback, datetime, re, Tkinter, tkFileDialog
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta, CreateMetaDict as MetaDict

# Declare a timestamp variable
timestamp = datetime.datetime.now()

# Script arguments hard-coded
srcGRID = r'E:\NLCD\NLCD2006_reproj\ClippedToState\nlcd06_utm18c'
ShpDir = r'D:\VulnerabilityModel\Shapefiles\WRS_Footprints\Buffered_Footprints\UTM18'
ClipDir = r'D:\VulnerabilityModel\Rasters\NLCD2006_derivs\Clips_UTM18'

#Get the list shapes to use
myShps = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(ShpDir)
             for f in files if (f.endswith('.shp') and not f.endswith('vqt.shp'))]

arcpy.env.overwriteOutput = True #Existing data may be overwritten

#Create and open a log file to write processing records
mylogfile = "ClipMask_log.txt"
mylogfile = ClipDir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Clip Mask Processing Log" + "\n" + "\n")
mylog.write("Source GRID: " + srcGRID + "\n")
mylog.write("Shapefile directory: " + ShpDir + "\n")
mylog.write("Directory to store output clipped images: " + ClipDir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")

#Loop through the image set
for SHP in myShps:
   try:
      print "Working on " + SHP
      
      #Extract the 5-digit WRS path/row identifier
      #Modify this bit if naming convention changes
      PathRow = basename(SHP)[8:13]
      
      #Declare output path
      outGRID = ClipDir + path.sep + 'NLCD06_' + PathRow + '.img'
      
      print srcGRID
      print outGRID
      print SHP
      
      #Clip the image
      print "Clipping..."
      arcpy.Clip_management (srcGRID, "#", outGRID, SHP, "255", "ClippingGeometry") 
      timestamp = datetime.datetime.now()
      
      #Confirmation of successful processing
      print "Successfully created clip for " + SHP
      mylog.write("Successfully created clip for " + SHP + "\n")
          
   except:
      mylog.write("Failed to produce clip for " + SHP + "\n")
      
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))

      print msgs
      print pymsg
      print arcpy.AddMessage(arcpy.GetMessages(1))
      
# Clean up (delete) the auxiliary files created by Arc
delList = [os.path.join(dirpath, f)
          for dirpath, dirnames, files in os.walk(ClipDir)
          for f in files if f.endswith(('.ovr', '.xml'))]
for f in delList:
   os.remove(f)

# Update the timestamp
timestamp = datetime.datetime.now()
mylog.write("Program execution completed at " + str(timestamp) + "\n")      
mylog.close()
   



