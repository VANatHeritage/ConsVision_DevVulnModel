# Paired_Points.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-07-05
# Creator:  Roy D. Gilb
#
# NOTE:  This script is not ready for prime time.  Currently, the corresponding ArcGIS tool Roy developed 
#        (Generate Paired Sample Points) is not included in the VulnModTools.tbx toolbox.  Paths
#        will need to be changed for this to work properly.  (K. Hazler, 8 October 2013)
#
# Summary: 
#   Generates one paired sample point per point on the input feature class file. User must specify a minimum and #   maximum distance from the orginal point so that the new point is placed within a "donut" at specified radii.
#     
# Usage Tips:   
#  * This script calls the command gencondrandompnts from the program GME (see spatialecology.com/gme).  
#    GME must be installed and paths correctly specified for this script to run.
#
# Syntax:
#   
#
# Required Arguments:
#  * inputPoints: The input feature class containing the original points file.
#  * outputPath: The directory to store the new paired points file.
#  * mindDist: The minumum distance (in the input file's units) to generate a new paired sample point.
#  * maxdist: The maximum distance (in the input file's units) to generate a new paired sample point.

# Temporary feature classes:

# Spatial reference objects:
#   
# Other local variables:
#   
#

# -------------------------------------------------------------------------------------------------------

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env
from arcpy.sa import *

#Parameters passed in from arc tool
inputPoints = arcpy.GetParameterAsText(0)
outputPath = arcpy.GetParameterAsText(1)
minDist = arcpy.GetParameterAsText(2)
maxDist = arcpy.GetParameterAsText(3)
myRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints'
binRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters'
pairedRoot = 'C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints'
uniqueList = []


#Get unique values for the rasters 
os.chdir(binRoot)
try:
#Recursively walk through all files and directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(binRoot):
      for filename in myFiles: 
         if filename.endswith(".shp") and filename.startswith("binaryClass"): #Find files that end with .shp and are the binary shapefiles
            s = filename[11:13]
            uniqueList.append(s)           

#Error handling
except IOError:
   arcpy.AddMessage("Error: can\'t find file or read data.")
else:
   arcpy.AddMessage("Successfully ran GME scripts.")

os.chdir(pairedRoot)
textFile = open("GME_PAIRED_SCRIPT.txt", "w")

#Loop to create txt GME scripts in PairedPoints directory
for val in uniqueList:
    arcpy.AddMessage('Creating GME Script files making paired sample points ' + str(val))     #Give user some processing feedback
   
    #Create a string variable for the path/name of the unique point shapefiles based on their value to access the 
    binPointPath = 'C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\BinRasters\\binaryClass' 
    binPointPath = binPointPath + str(val) + '.shp'
   
   
    os.chdir('C:\\Gilb_VulnMod\\Arc_Test\\RandPoints\\PairedPoints')
    
    #Create properly formatted string for running GME gencondrandompnts command and write that string to a unique txt file
    myInfo = "gencondrandompnts(in=\"" + str(binPointPath) + "\", "  + "uidfield=\"FID\""  + ", sample=\"1\"" + ", distrib=c(\"" + "BVUNIFORM\"" + ", " + str(minDist) + ", " + str(maxDist) + ")" + ", out=\"" + outputPath + "\\pairedClass"  + str(val) + ".shp" + "\");"

    textFile.write(myInfo + "\n")                                      #Populate the txt file with a GME command 
    
textFile.close()
    



#Loop to call txt GME scripts within PairedPoints directory
#FROM GenRandPoints.py code

try:
#Recursively walk through all files and directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(pairedRoot):
      for filename in myFiles: 
         if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
            #Change current directory to the directory referenced by walk (contains txt files)
            os.chdir(pairedRoot)
            
            #Properly format the GME call as a string and use subprocess.call to run the GME script from within each txt file
            gmeCall = r'C:\\Software\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints' + '\\' + filename + '\\");'      
            subp.call(gmeCall);             #subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\");');
            
            #User feedback
            arcpy.AddMessage("Running file: " + filename)
            

#Error handling
except IOError:
   arcpy.AddMessage("Error: can\'t find file or read data.")
else:
   arcpy.AddMessage("Successfully ran GME scripts.")


   
#Merge shapefiles
tmp = "pairedClass"
os.chdir("C:\Gilb_VulnMod\Arc_Test\RandPoints\PairedPoints")
arcpy.env.workspace = pairedRoot

#Get a list of all the shapefiles containing random sample points on each raster class value
fcs = arcpy.ListFeatureClasses()

for fc in fcs:
  tmpVal = fc[11: fc.find('.shp')]      #Substring call on the feature classes filename to extract the original class number
  arcpy.AddField_management(fc, 'CLASSVALUE','text')    #Add a field called CLASSVALUE
  arcpy.CalculateField_management(fc, 'CLASSVALUE', '"'+tmpVal+'"')
arcpy.Merge_management(fcs, 'pairedPointsOut.shp')                                    #Code idea from http://gis.stackexchange.com/questions/7007/batch-shapefile-merge-with-adding-and-calculating-field
    
 
   
   
#GME CALL
#gencondrandompnts(in="C:\Gilb_VulnMod\Arc_Test\RandPoints\BinRasters\myOut.shp", uidfield="FID", sample="1", distrib=c("BVUNIFORM", 22, 55), out="C:\Gilb_VulnMod\Arc_Test\Shp\cond_points1.shp");
