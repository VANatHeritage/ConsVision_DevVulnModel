# -----------------------------------------------------------------------------------------
# FOOTPRINT_SIDEERASE.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-11-13
# Last Edit:  2013-11-13
# Creator:  Kirsten R. Hazler
#
# Summary:
#     Reduces the Landsat WRS footprints on the east-west sides only, to eliminate the "zipper"
#     effect.  Requires the existence of the footprint sidelines, which were created previously.
#
# Usage Tips:
#     This script will only work if both the original footprints and the sidelines are named 
#     according to a regular, such that the path/row are identified and matched.  Each shapefile 
#     should contain only a single footprint polygon or set of right and left sidelines.
#
#     The footprints must be named as follows:
#        *####.shp
#        where "*" represents a string of any length and #### is a four-digit path/row identifier
#
#     The sidelines must be named as follows:
#        ####sidelines.shp
#        where #### is a four-digit path/row identifier
#
# Required Arguments:
#     myFPdir:  Directory containing the footprint polygon shapefiles
#     mySLdir:  Directory containing the sideline shapefiles
#     myOutDir:  Directory to store output shapefiles
#     myBuffDist:  The buffer distance for the sidelines (to be chopped out of footprints)
# -----------------------------------------------------------------------------------------

# Import required modules
import arcpy, os, os.path as path, sys, traceback, datetime
from os.path import basename

# Script arguments hard-coded
myFPdir = r'D:\VulnModWork_RoyArchive\BufferedFootprints\DELETEME_DUPLICATE_FinalBuffers'
mySLdir = r'D:\VulnModWork_RoyArchive\BufferedFootprints\Sidelines'
myOutDir = r'D:\VulnerabilityModel\Shapefiles\WRS_Footprints\Buffered_Footprints'
myBuffDist = 16000

# Temporary feature classes
BuffFeat = "in_memory" + os.sep + "tmpBuffFeat"

# Get the list of footprints to process
myFootprints = [os.path.join(dirpath, f)
               for dirpath, dirnames, files in os.walk(myFPdir)
               for f in files if (f.endswith('.shp') and not f.endswith('.shp_vqt.shp'))]

# Allow existing data to be              
arcpy.env.overwriteOutput = True 

# Declare a timestamp variable
timestamp = datetime.datetime.now()

#Create and open a log file to write processing records
mylogfile = "FootprintBuffer_log.txt"
mylogfile = myOutDir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Footprint Side-buffer Log" + "\n" + "\n")
mylog.write("Source footprint directory: " + myFPdir + "\n")
mylog.write("Sidelines directory: " + mySLdir + "\n")
mylog.write("Directory to store output buffered footprints: " + myOutDir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")

# Loop through the footprint set
for FP in myFootprints:
   try:    
      # Split the footprint basename from its extension
      FPbn, FPext = path.splitext(basename(FP))
      print "Basename: " + FPbn
      
      # Extract the path/row identifiers from the basename
      myPathRow = FPbn[-4:]
      myRow = FPbn[-2:]
      myPath = FPbn[-4:-2]
      my5dig = myPath + '0' + myRow
      
      # Specify the output shapefile
      mySideBuffFP = myOutDir + os.sep + "SideBuff" + my5dig + ".shp"
      
      # Get the sideline file with the corresponding path/row, and buffer it
      mySL = mySLdir + os.sep + myPathRow + 'sidelines.shp'
      arcpy.Buffer_analysis(mySL, BuffFeat, str(myBuffDist) + " meters", "", "","ALL", "")
      
      # Use the buffer feature to erase the sides of the footprint
      arcpy.Erase_analysis(FP, BuffFeat, mySideBuffFP, "")
      
      # Confirmation of successful processing
      print "Successfully created " + mySideBuffFP
      mylog.write("Successfully processed " + mySideBuffFP + "\n")
      
   except:
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))

      print msgs
      print pymsg
      print arcpy.AddMessage(arcpy.GetMessages(1))
      
mylog.close()
