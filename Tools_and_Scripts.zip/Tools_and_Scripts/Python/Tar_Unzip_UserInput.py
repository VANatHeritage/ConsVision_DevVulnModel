# -------------------------------------------------------------------------------------------------------
# Tar_Unzip_UserInput.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-10
# Last Edit: 2014-03-12
# Creator:  Roy D. Gilb
# Edited/Revised by:  Kirsten R. Hazler
#
# Summary:
#     *Given a root directory, recursively loops through all subdirectories to extract 
#      data from from tar.gz files contained therein.  Extracted files are placed in the 
#      same directory as the corresponding tar.gz file.
# Usage Tips:
#     *Script only works with tar.gz files, and was specifically developed for Landsat files
#      obtained from USGS.
# Required Arguments:
#     *rootDir: Root directory where the script begins its recursive walk through all subdirectories
# Other local variables:
#     count: Simple count integer to provide user with output statements of how many tar.gz files 
#               have been extracted
#     myFailList: List to store IDs of files that fail to get processed
#     myFailLog: Text file storing features that fail to get processed
#
# -------------------------------------------------------------------------------------------------------

# Import required modules
import os, os.path as path, sys, traceback, Tkinter, tkFileDialog, tarfile

# Prepare dialog - Tkinter gobblety-gook
# Make a top-level instance and hide since it is ugly and big.
root = Tkinter.Tk()
root.withdraw()

# Make it almost invisible - no decorations, 0 size, top left corner.
root.overrideredirect(True)
root.geometry('0x0+0+0')

# Show window again and lift it to top so it can get focus,
# otherwise dialogs will end up behind the terminal.
root.deiconify()
root.lift()
root.focus_force()

# Script argument entered by user at prompts
rootDir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory containing tar.gz files')
print "Source Directory: " + rootDir

myFailList = []                        #Empty list to store IDs of files that fail to get processed
myFailLog = r"D:\Temp\Landsat_TestFailLog.txt"     #Text file storing features that fail to get processed
count = 1                              #Count variable used within for loop to track number of files

try:
#Recursively walk through all directories starting with the root (rootDir)
      #print "The directory %s has subdirectory %s and files %s" % (root, dirs, myFiles)   #Directory tracking  
   for root, dirs, myFiles in os.walk(rootDir):
      for filename in myFiles: 
         if filename.endswith("tar.gz") and ".TIF" not in myFiles: #Find files that end with tar.gz and haven't been extracted yet
            #Output for user
            print(str(count) + ") Extracting tar.gz file: " + filename)                               
            count = count + 1
            
            #Change current directory to the directory referenced by walk (contains tar.gz file) and extract the tar.gz file contained
            os.chdir(root)
            
            try:
                tar = tarfile.open(filename)     #Open and extract tar files 
                try:
                    tar.extractall()
                finally:
                    tar.close()
            except IOError:
                print("Error: can\'t find tar.gz file or read data.")
                myFailList.append(myID)
                
                # Add status message
                print "Moving on to the next file.  Note that the extraction will be incomplete."      
                 
                        
#Error handling
except IOError:
   print("Error: can\'t find file or read data.")
finally:
# Once the script as a whole has succeeded, let the user know if any individual features failed
    if len(myFailList) == 0:
        print "All files successfully extracted"
    else:
        print "Extraction failed for the following files: " + str(myFailList)
        print ("See the log file " + myFailLog)
