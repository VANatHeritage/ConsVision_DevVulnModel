# Matched_Points.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-10-09
# Creator:  Roy D. Gilb and Kirsten R. Hazler
#
# Summary: 
#   For each point in an input feature class, one or more matched sample points are randomly placed 
#   within the distance parameters specified.   
#     
# Usage Tips:   
#   * This script calls the command gencondrandompnts from the program GME (see spatialecology.com/gme).  
#   * GME must be correctly installed and its path correctly specified for this script to run.  
#   * The user may need to modify the value of the segme variable to specify the correct path.
#
# Syntax:
#   
# Required Arguments:
#   inFile: The feature class containing the reference points
#   outFile: The feature class to which the matched points will be saved
#   PtID: The field containing the unique ID for each reference point
#   nSamples: The number of matched points to generate for each reference point
#   minDist: The minimum distance a matched point must be from its reference
#   maxDist: The maximum distance a matched point can be from its reference
#   myScriptDir: A directory in which the resulting GME script will be stored.

# Temporary feature classes:

# Spatial reference objects:
#   
# Other local variables:
#   segme:  the path to the GME executable program, segme.exe
#   MyScriptFile:  a text file in which GME commands are stored.
#   MyWriteFile:  an instance of MyScriptFile, opened for writing
#   var1-5:  lines of code declaring variables in GME script
#   mycmd:  line of code generating the sample points in GME script
#   mycall:  call to the GME script to be executed
#   
# -------------------------------------------------------------------------------------------------------

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env
from arcpy.sa import *

# # Parameters to be passed in from arc tool
# # Comment this out if running as standalone script
# inFile = arcpy.GetParameterAsText(0) # The feature class containing the reference points
# outFile = arcpy.GetParameterAsText(1) # The feature class to which the matched points will be saved
# PtID = arcpy.GetParameterAsText(2) # The field containing the unique ID for each reference point
# nSamples = arcpy.GetParameterAsText(3) # The number of matched points to generate for each reference point
# minDist = arcpy.GetParameterAsText(4) # The minimum distance a matched point must be from its reference
# maxDist = arcpy.GetParameterAsText(5) # The maximum distance a matched point can be from its reference
# myScriptDir = arcpy.GetParameterAsText(6) # A directory in which the resulting GME script will be stored.

# Parameters for running standalone script
# Comment this out if running as ArcGIS tool
inFile = r"D:\VulnerabilityModel\Testing\Script_Testing\match_test2.shp" 
outFile = r"D:\VulnerabilityModel\Testing\Script_Testing\match_test2_GenMatchedPts8.shp" 
PtID = "FID" # The field containing the unique ID for each reference point
nSamples = "3"
minDist = "5"
maxDist = "20"
myScriptDir = r"D:\VulnerabilityModel\Testing\Script_Testing"

# Set the path to the GME program.  
# THIS MAY NEED MODIFICATION DEPENDING ON WHERE THE PROGRAM WAS INSTALLED!
segme = "C:\\Program Files (x86)\\SpatialEcology\\GME\\segme"

# Set overwrite option so that existing data may be overwritten
arcpy.env.overwriteOutput = True 

try:
    myScriptFile = myScriptDir + os.sep + "Gen_MatchedPoints.gme"
    
    # Write a correctly formatted GME script that applies the command gencondrandompnts to input parameters.
    # First create the lines declaring the variables
    var1 = 'inFile <- "' + inFile + '";'
    var2 = 'PtID <- "' + PtID + '";'
    var3 = 'nSamples <- ' + nSamples + ';'
    var4 = 'dist <- c("BVUNIFORM",' + minDist + ',' + maxDist + ');'
    var5 = 'outFile <- "' + outFile + '";'
    
    # Create the command syntax
    mycmd = 'gencondrandompnts(in=inFile, uidfield=PtID, sample=nSamples, distrib=dist, out=outFile);'
    
    # Write the lines of code to the GME file
    arcpy.AddMessage("Writing GME script file")
    print "Writing GME script file"
    myWriteFile = open(myScriptFile, "w")  
    myWriteFile.write(var1 + "\n" +\
                      var2 + "\n" +\
                      var3 + "\n" +\
                      var4 + "\n" +\
                      var5 + "\n" +\
                      mycmd)                      
    myWriteFile.close()
    
    # Call the script and run it
    arcpy.AddMessage("Running GME script file")
    print "Running GME script file"
    mycall = segme + ' -c run(in=\\"' + myScriptFile + '\\")'
    subp.call(mycall)
    
    arcpy.AddMessage("Mission accomplished")
    print "Mission accomplished"
    
except:
    # Error handling code swiped from "A Python Primer for ArcGIS"
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
    msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

    arcpy.AddError(msgs)
    arcpy.AddError(pymsg)
    arcpy.AddMessage(arcpy.GetMessages(1))

    print msgs
    print pymsg
    print arcpy.AddMessage(arcpy.GetMessages(1))
