# ---------------------------------------------------------------------------
# BackdateVertRast.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-05-05
# Last Edit: 2016-05-05
# Creator:  Kirsten R. Hazler
#
# Summary:
# Creates a backdated vertical raster from roads inputs.  The output can be used to determine vertical cost factors in a Path Distance analysis.
#
# Syntax: 
# BackdateVertRast <Input_Resampled_Imperviousness_Raster> <Input_Roads_Rasterized_by_Unique_ID> <Input_Roads_Rasterized_by_Type> <Input_Snap_Raster> <Scratch_GDB> <Backdated_Vertical_Factor_Raster> 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy
import os # provides access to operating system funtionality 
import sys # provides access to Python system functions
import traceback # used for error handling

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

# Script arguments to be input by user
in_5mImp = arcpy.GetParameterAsText(0) # Input 5-m resampled inperviousness raster
in_RoadZones = arcpy.GetParameterAsText(1) # Input roads rasterized by unique ID
in_RegRoads = arcpy.GetParameterAsText(2) # Input rasterized regular roads
in_Ramps = arcpy.GetParameterAsText(3) # Input rasterized ramps
in_Hwys = arcpy.GetParameterAsText(4) # Input rasterized highways
in_Snap = arcpy.GetParameterAsText(5) # Input snap raster
out_Scratch = arcpy.GetParameterAsText(6) # Scratch geodatabase
out_VertRast = arcpy.GetParameterAsText(7) # Output vertical raster

# Additional variables and environment settings:
cell_fact = "6"
reg = out_Scratch + os.sep + "reg"
rmp = out_Scratch + os.sep + "rmp"
hwy = out_Scratch + os.sep + "hwy"
arcpy.env.snapRaster = in_Snap
arcpy.env.mask = in_Snap
arcpy.env.overwriteOutput = True 

# Process: Zonal Statistics
arcpy.AddMessage("Computing zonal statistics")
zoneStats = ZonalStatistics (in_RoadZones, "Value", in_5mImp, "MAXIMUM", "DATA")
zoneStats.save(out_Scratch + os.sep + "zoneStats")

# Process roads rasters in loop
for rast in [(in_RegRoads, reg, 30), (in_Ramps, rmp, 90), (in_Hwys, hwy, 150)]:
   # Process: Raster Calculator (Backdate)
   arcpy.AddMessage("Backdating (%s)" %rast[0])
   rast_val = rast[2]
   in_rast = Raster(rast[0])*rast_val
   backdt = Con (zoneStats > 0, in_rast)

   # Process: Aggregate 
   arcpy.AddMessage("Aggregating")
   aggr = Aggregate (backdt, cell_fact, "MINIMUM", "", "DATA")
   out_rast = rast[1]
   aggr.save(out_rast)

# Get mean values for road cells
arcpy.AddMessage("Computing cell statistics with gp")
# meanRast = CellStatistics ([reg, rmp, hwy], "MEAN", "DATA")
# meanRast.save(out_Scratch + os.sep + "meanRast")
meanRast = out_Scratch + os.sep + "meanRast"
arcpy.gp.CellStatistics_sa("%s;%s;%s" % (reg, rmp, hwy), meanRast, "MEAN", "DATA")

# Finalize vertical raster
arcpy.AddMessage("Finalizing")
vertRast = Con(IsNull(meanRast), 0, meanRast)
vertRast.save(out_VertRast)

