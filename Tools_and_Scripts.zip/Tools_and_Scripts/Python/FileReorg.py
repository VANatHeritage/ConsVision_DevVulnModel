# ------------------------------------------------------------------------------------------
# FileReorg.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-12-03
# Last Edit:  2013-12-03
# Creator:  Kirsten R. Hazler
#
# Summary:
#     Reorganizes file/directory structure
#
#  Usage Tips:
#
# Required Arguments:
#     SrcDir:  The main directory
# ------------------------------------------------------------------------------------------

# Import required standard modules
import os, os.path as path, sys, traceback, datetime, re
from os.path import basename

# Hard-coded script arguments
SrcDir = r"E:\Landsat\Landsat_PROC\2_CLIP"

#Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(SrcDir)
             for f in files]
            
for SrcImg in mySrcImgs:
   try:
      print "Working on " + SrcImg
      
      # Determine the names of subdirectories
      PathRow = basename(SrcImg)[0:5]
      TSind = basename(SrcImg)[13]
      ThermDir = SrcDir + os.sep + 'THERM' + os.sep + PathRow
      print ThermDir
      SpectDir = SrcDir + os.sep + 'SPECT' + os.sep + PathRow
      print SpectDir

      # Move the files (create subdirectories as needed)
      if not os.path.isdir(ThermDir):
         os.makedirs(ThermDir)
      if not os.path.isdir(SpectDir):
         os.makedirs(SpectDir)
      if TSind == "S":
         os.rename(SrcImg, SpectDir + os.sep + basename(SrcImg))
      elif TSind == "T":
         os.rename(SrcImg, ThermDir + os.sep + basename(SrcImg))
         
   except:
      # Error handling code modified from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      print pymsg
      print "Mask Build failed for " + SrcImg


