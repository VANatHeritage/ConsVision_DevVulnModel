# ------------------------------------------------------------------------------------------
# Build_Mask_From_Img.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-11-22
# Last Edit:  2013-11-26
# Creator:  Kirsten R. Hazler
#
# Summary:
#     This script is a wrapper for IDL code which does the actual processing.  It iterates through all
#     files contained within the designated input directory and all its subdirectories, creating binary
#     masks based on the specified NoData value (= data ignore value).
#
#  Usage Tips:
#     (1) For multi-band images, this script assumes that the locations of the first band's NoData 
#     values are representative for all bands (that is, the mask is based entirely on the first
#     band.)
#     (2) This tool was developed to work with Landsat-derived files following a naming convention
#     where the first 5 characters (digits) in the source file name indicate the Landsat path/row.
#     These first 5 characters are used to name the corrseponding output masks.
#
# Required Arguments:
#     SrcDir:  the directory containing source image files
#     MskDir:  the directory to contain the output mask files
#     NoDataVal:  the number value representing "NoData" in the source images
# ------------------------------------------------------------------------------------------

# Import required standard modules
import os, os.path as path, sys, traceback, datetime, re, Tkinter, tkFileDialog
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta, CreateMetaDict as CreateMeta, DeleteMeta as DelMeta, ENVI_HDRfix as hdrfix
from CallSub import Call_IDLpro as ipro

# Prepare dialog - Tkinter gobblety-gook
# Make a top-level instance and hide since it is ugly and big.
root = Tkinter.Tk()
root.withdraw()

# Make it almost invisible - no decorations, 0 size, top left corner.
root.overrideredirect(True)
root.geometry('0x0+0+0')

# Show window again and lift it to top so it can get focus,
# otherwise dialogs will end up behind the terminal.
root.deiconify()
root.lift()
root.focus_force()

# Script arguments enter by user at prompts
SrcDir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory containing source images')
MskDir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory to store output mask images')
NoDataVal = raw_input('Enter a NoData value:\n')

# # Hard-coded script arguments
# SrcDir = r"D:\VulnMod_Testing\Clips\SPECT"
# MskDir = r"D:\VulnMod_Testing\Masks"
# NoDataVal = "999"

# Create variable to reference the IDL script
idl_pro = 'Build_Mask_From_Img'

#Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(SrcDir)
             for f in files if f.endswith('.dat')]

for SrcImg in mySrcImgs:
   try:
      print "Working on " + SrcImg
      
      # Declare the output mask name
      PathRow = basename(SrcImg)[0:5]
      MskImg = MskDir + path.sep + PathRow + '_MSK.dat'
      print MskImg
      
      # Gather the parameters into a list
      params_list = [SrcImg, MskImg, NoDataVal]
      print params_list
      
      # Run the IDL script
      print "Running IDL script"
      idl_err = ipro(idl_pro, params_list)
      
      if len(idl_err) == 0:
         # Confirmation of successful processing
         print "Successfully created mask for %s" %SrcImg
         print "Now editing metadata..."
         
         try:
            # Then do other text-processing cleanup with the MskImg header
            hdrfix(MskImg)
            
            myMetaDict = CreateMeta(MskImg)
            myMetaDict['description'] = 'Mask for %s' %PathRow
            myOldLin = myMetaDict.get('lineage', 'missing')
            myNewLin = myOldLin.replace('}', ', Derived Mask Image: %s}' %MskImg)
            myMetaDict['lineage'] = myNewLin
            myMetaDict['default stretch'] = '0.0 1.0 linear'

            myKeyList = ('description', 'lineage', 'default stretch')
            for myKey in myKeyList:
               print myKey + ' = ' + myMetaDict[myKey]
            ReplMeta(MskImg, myKeyList, myMetaDict)
            myDelList = ('wavelength units', 'wavelength', 'data ignore value')
            DelMeta(MskImg, myDelList)
            
         except:
            print "Mask created, but metadata editing failed"
            # Error handling code modified from "A Python Primer for ArcGIS"
            tb = sys.exc_info()[2]
            tbinfo = traceback.format_tb(tb)[0]
            pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
            print pymsg
            print "Mask Build failed for " + SrcImg
         
      else:
         print "Failed to produce mask for %s" %SrcImg
         print idl_err

   except:
      # Error handling code modified from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      print pymsg
      print "Mask Build failed for " + SrcImg

print "Processing Complete"
print "For details, see the log file 'MaskBuild_IDL_log.txt' in your output directory"
