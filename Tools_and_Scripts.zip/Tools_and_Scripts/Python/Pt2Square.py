# -------------------------------------------------------------------------------------------------------
# Pt2Square.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-09-05
# Last Edit: 2013-09-09
# Creator:  Kirsten R. Hazler
#  
#  Summary:
#     Creates squares of specified size around central points.  
#
#  Usage Tips:
#     This tool was designed for the purpose of creating squares that align exactly with the pixels of 
#     Landsat imagery or other raster data.  For this purpose to be achieved, it is necessary that:
#        1) the source points occur exactly in the center of the pixels with which the squares should align
#        2) the specified side-lenth of the output squares correspond to an uneven number of pixels.
#           For example, if pixel size is 30m, then you might specify a square length of 90m (= 3 pixels)
#
#  Syntax:
#     Pt2Square(<InPoints>, <InID>, <OutPolys>, <SqrLen>)

#  Required Arguments:
#     InPoints:  An input point feature class from which squares will be generated
#     InID:  An input ID field to identify points and their corresponding output squares
#     OutPolys:   An output polygon feature class containing the square shapes
#     SqrLen:    Side dimension of the squares; length of a side

#  Import required modules
import arcpy # provides access to all ArcGIS geoprocessing functions
import os # provides access to operating system funtionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
#import math

# Script arguments to be input by user...
# Comment out this section if running as a stand-alone script.  Uncomment if running as ArcGIS tool.
InPoints = arcpy.GetParameterAsText(0) # input point features
InID = arcpy.GetParameterAsText(1) # ID field to identify points and corresponding squares
OutPolys = arcpy.GetParameterAsText(2) # output square polygon features
SqrLen= arcpy.GetParameter(3) # desired dimension (side length) of the output squares 

# # Script arguments to be used when running stand-alone, outside of ArcGIS:
# # Modify inputs as needed.
# # Comment out this section if running through an ArcGIS tool.  Uncomment if running as stand-alone script.
# InPoints = r"C:\DCR_Work\InfoMgmt\VulnerabilityModel\Testing\Random\25goodpts.shp"
# InID = "POINTID"
# OutPolys = r"C:\DCR_Work\InfoMgmt\VulnerabilityModel\Testing\Random\25squaresc.shp"
# SqrLen = 150

# Declare path/name of output data and workspace
drive, path = os.path.splitdrive(OutPolys) 
path, filename = os.path.split(path)
myWorkspace = drive + os.sep + path
Output_Polys_fname = filename

#  Set environmental variables
arcpy.env.overwriteOutput = True # Set overwrite option so that existing data may be overwritten

try:
   #  Get spatial reference
   mySR = arcpy.Describe(InPoints).spatialReference
   arcpy.AddMessage("\nThe spatial reference of your input is " + str(mySR.name))
   print "The spatial reference of your input is " + str(mySR.name)

   # Set the distance to be used for generating vertices from central point
   SideDim = SqrLen/2

   #  Process:  Create Feature Class (Data Management)
   #  Create a feature class to store polygons
   arcpy.AddMessage("Creating polygon feature class...")
   print "Creating polygon feature class..."
   arcpy.CreateFeatureclass_management (myWorkspace, Output_Polys_fname, "POLYGON", "", "", "", mySR)

   #  Process:  Add Field (Data Management)
   arcpy.AddField_management (OutPolys, InID, "TEXT", "", "", 10, "", "", "", "")

   #  Create and insert cursor for the square polygon table
   mySquareCursor = arcpy.da.InsertCursor(OutPolys, ["SHAPE@", InID]) 

   for myPoint in arcpy.da.SearchCursor(InPoints, [InID, "SHAPE@XY"]):
       #  Get point ID
       myID = myPoint[0]
       arcpy.AddMessage("Creating square for point ID " + str(myID))
       print "Creating square for point ID " + str(myID)
       
       #  Get xy coordinates, then calculate coordinates of corner vertices
       #print "Getting point xy coordinates and calculating square vertices"
       x, y = myPoint[1]
       x1, y1 = [x+SideDim, y+SideDim]
       x2, y2 = [x+SideDim, y-SideDim]
       x3, y3 = [x-SideDim, y-SideDim]
       x4, y4 = [x-SideDim, y+SideDim]
       p1 = arcpy.Point(x1,y1)
       p2 = arcpy.Point(x2,y2)
       p3 = arcpy.Point(x3,y3)
       p4 = arcpy.Point(x4,y4)
       myArray = arcpy.Array([p1, p2, p3, p4])
       
       # Create polygon from vertices
       #print "Creating square from vertices"
       myPoly = arcpy.Polygon(myArray)
       
       # Create and insert new polygon feature
       mySquareCursor.insertRow([myPoly, myID])
except:
   # Error handling code swiped from "A Python Primer for ArcGIS"
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

   arcpy.AddError(msgs)
   arcpy.AddError(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))

   print msgs
   print pymsg
   print arcpy.AddMessage(arcpy.GetMessages(1))

finally:   
   if mySquareCursor:
      del mySquareCursor 

