# ----------------------------------------------------------------------------------------
# EmploymentOpps.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-02-17
# Last Edit: 2016-02-17
# Creator:  Kirsten R. Hazler
#
# Summary:
#  Creates a raster representing employment opportunities 
# ----------------------------------------------------------------------------------------
ScriptDate = '2016-02-17' # Used for informative message down below

# Import necessary modules
import arcpy
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
import os # provides access to operating system functionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
import gc # garbage collection
from datetime import datetime # for time-stamping

# Script arguments to be input by user...
inBizPts = arcpy.GetParameterAsText(0) 
   # Input point feature class representing business locations
fld_EmpNum = arcpy.GetParameterAsText(1) 
   # The name of the field containing the number of employees working at the location
fld_ID = arcpy.GetParameterAsText(2)
   # The name of the field containing a unique ID for each business location
inCostSurf = arcpy.GetParameterAs Text(2)
   # Input travel time cost surface, representing time required to traverse one meter
maxTravTime = arcpy.GetParameterAsText(3)
   # The maximum travel time, in minutes, to be considered in Cost Distance analysis
scratchGDB = arcpy.GetParameterAsText(4) 
   # A geodatabase for storing intermediate/scratch products
outputGDB = arcpy.GetParameterAsText(5) 
   # An geodatabase for storing final products

# Set overwrite option so that existing data may be overwritten
arcpy.env.overwriteOutput = True 
   
# Define functions for generating warning messages
def warnings(BizID):
   warnMsgs = arcpy.GetMessages(1)
   if warnMsgs:
      arcpy.AddWarning('Finished processing business %s, but there were some problems.' % str(int(BizID))
      arcpy.AddWarning(warnMsgs)
   else:
      arcpy.AddMessage('Business %s processing completed' % str(int(BizID))
      
def tback():
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

   arcpy.AddError(msgs)
   arcpy.AddError(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))

# Make a stupid joke   
arcpy.AddMessage('Why did the programmer cross the road?')
arcpy.AddMessage('To get away from the Python.')
arcpy.AddMessage('Ha ha ha.')
      
# Print helpful messages to geoprocessing window
arcpy.AddMessage("Your input business locations feature class is: \n %s" % inBizPts)
arcpy.AddMessage("Your input cost surface raster is: \n %s" % inCostSurf)
arcpy.AddMessage("Your intermediate products will be stored in: \n %s" % scratchGDB)
arcpy.AddMessage("Your final products will be stored in: \n %s" % outGDB)
arcpy.AddMessage("The running script was last edited %s" % ScriptDate)

# Create an empty list to store IDs of features that fail to get processed
myFailList = []

# Create an empty list to store paths of output rasters
myRastList = []

# Set environmental variables
arcpy.env.workspace = outGDB # Set the workspace for geoprocessing
arcpy.env.scratchWorkspace = scratchGDB # Set the scratch workspace for geoprocessing
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = inCostSurf # Set the snap raster 

# Make a constant raster set to zeros to cover the desired extent.  Call it EmpSum.

# Loop through the individual point features
myBizPts = arcpy.da.SearchCursor(inBizPts, [fld_ID, fld_EmpNum]) # Get the set of features

for myPt in myBizPts: # for each point in the set, do the following...
   try: # Even if one feature fails, script can proceed to next feature
      # Extract the relevant attributes from the data record
      BizID = myPt[0] # Is this a number or string?  May require code mods below depending on field type
      Num = myPt[1]
      
      # Add a progress message
      arcpy.AddMessage("\nWorking on business point %s..." % myID)

      # Reset processing extent, because ArcGIS is stupid.
      myExtent = str(arcpy.Describe(inCostSurf).extent).replace(" NaN", "")
      arcpy.env.extent = myExtent
      
      # Process:  Select (Analysis)
      # Create a temporary feature class including only the current business
      myCurrentPt = outScratch + os.sep + "tmpPt"
      myWhereClause = '"' + fld_ID + '" = ' + str(int(myID))
      arcpy.Select_analysis (inBizPts, myCurrentPt, myWhereClause)
      
      # Convert the current point to raster.  
      # Make sure to snap to the cost surface and specify the correct cell size
      
      
      # Run the cost distance analysis out to the maximum travel time
      # Anything farther than that travel time will be NoData in the output
      
      
      # Recode the cost distance raster so that the cell value is the employment number
      # where there's a travel time, and zeros replace the NoData.
    
      # Save the final raster for the point
      outRast = outGDB + os.sep + 'EmpNum_' + str(int(myID)
      
      # Use Cell Statistics tool to add current raster to the EmpSum raster(sum)
      # Use the DATA option (so NoData cells are ignored)
      # Make sure to use the extent from EmpSum, not the smaller raster!!
      # Call the output tmpSum
      # Replace EmpSum with tmpSum
      
      warnings(BizID)
   except:
      arcpy.AddWarning('Unable to process business %s' % myID)
      tback()








