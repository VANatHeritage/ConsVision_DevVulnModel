# ----------------------------------------------------------------------------------------------
# CallSub.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-11-25
# Last Edit: 2013-11-25
# Creator: Kirsten R. Hazler
#
# Summary: 
#  A set of functions to help with subprocess calls
# ----------------------------------------------------------------------------------------------
import subprocess as subp

def Call_IDLpro(idl_pro, params_list):
# Executes an IDL program (*.pro file)using a list of parameters as the arguments

   # Convert the list of parameters into a correctly formatted string
   params_list = ["'%s'" %item for item in params_list]
   params = ", ".join(params_list)

   # Create the IDL command string by combining the program name with the parameters
   idl_cmd = idl_pro + ", %s" %params

   # Create the command to submit to the subprocess module
   sub_cmd = 'idl -e "%s"' %idl_cmd

   # Invoke the subprocess
   sub_out = subp.Popen(sub_cmd, stderr = subp.PIPE, stdout = subp.PIPE)

   # Get info back from the subprocess
   (idl_out, idl_err) = sub_out.communicate()
   print idl_out
   print 'Errors: ' + idl_err
   return idl_err