# -------------------------------------------------------------------------------------------------------
# Tar_Unzip.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-10
# Last Edit: 2013-06-28
# Creator:  Roy D. Gilb
# Final Cosmetic Edits by:  Kirsten R. Hazler, 2013-10-02
#
# Summary:
#     *Given a root directory, recursively loops through all subdirectories to extract 
#      data from from tar.gz files contained therein.  Extracted files are placed in the 
#      same directory as the corresponding tar.gz file.
# Usage Tips:
#     *Script may be run directly or from associated ArcGIS tool "Extract Tar Files".
#     *Script only works with tar.gz files, and was specifically developed for Landsat files
#      obtained from USGS.
# Required Arguments:
#     *rootDir: Root directory where the script begins its recursive walk through all subdirectories
# Other local variables:
#     count: Simple count integer to provide user with output statements of how many tar.gz files 
#               have been extracted
#     myFailList: List to store IDs of files that fail to get processed
#     myFailLog: Text file storing features that fail to get processed
#
# -------------------------------------------------------------------------------------------------------

# Import required modules
import arcpy # provides access to all ArcGIS geoprocessing functions
import os, os.path # provides access to operating system funtionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
import tarfile # provides access to tar file handling and extraction

# # Script arguments to be used when running through ArcGIS tool
# # Comment out this section if running as a stand-alone script.  Uncomment if running through tool.
# rootDir = arcpy.GetParameterAsText(0)  #Root directory with Landsat tar.gz files      

# Script arguments to be used when running stand-alone, outside of ArcGIS:
# Modify inputs as needed.
# Comment out this section if running through an ArcGIS tool.  Uncomment if running as stand-alone script.
rootDir = r'D:\Temp\Test'                #For standalone py script

# Keep this bit regardless of how it's run
myFailList = []                        #Empty list to store IDs of files that fail to get processed
myFailLog = r"D:\Temp\Landsat_TestFailLog.txt"     #Text file storing features that fail to get processed
count = 1                              #Count variable used within for loop to track number of files

try:
#Recursively walk through all directories starting with the root (rootDir)
      #print "The directory %s has subdirectory %s and files %s" % (root, dirs, myFiles)   #Directory tracking  
   for root, dirs, myFiles in os.walk(rootDir):
      for filename in myFiles: 
         if filename.endswith("tar.gz") and ".TIF" not in myFiles: #Find files that end with tar.gz and haven't been extracted yet
            #Output for user
            print(str(count) + ") Extracting tar.gz file: " + filename)                               
            arcpy.AddMessage(str(count) + ") Extracting tar.gz file: " + filename)
            count = count + 1
            
            #Change current directory to the directory referenced by walk (contains tar.gz file) and extract the tar.gz file contained
            os.chdir(root)
            
            try:
                tar = tarfile.open(filename)     #Open and extract tar files 
                try:
                    tar.extractall()
                finally:
                    tar.close()
            except IOError:
                print("Error: can\'t find tar.gz file or read data.")
                arcpy.AddMessage("Error: can\'t find tar.gz file or read data.")
                myFailList.append(myID)
                
                # Add status message
                arcpy.AddMessage("\nMoving on to the next file.  Note that the extraction will be incomplete.")
                print "Moving on to the next file.  Note that the extraction will be incomplete."      
                 
                        
#Error handling
except IOError:
   print("Error: can\'t find file or read data.")                         
   arcpy.AddMessage("Error: can\'t find tar.gz file or read data.")
else:
   print("Successfully extracted tar files.")
   arcpy.AddMessage("Successfully extracted tar files.")                  
finally:
# Once the script as a whole has succeeded, let the user know if any individual features failed
    if len(myFailList) == 0:
        print "All files successfully extracted"
        arcpy.AddMessage("All files successfully extracted")
    else:
        print "Extraction failed for the following files: " + str(myFailList)
        arcpy.AddMessage("Extraction failed for the following files: " + str(myFailList))
        print ("See the log file " + myFailLog)
        arcpy.AddMessage("See the log file " + myFailLog)  
