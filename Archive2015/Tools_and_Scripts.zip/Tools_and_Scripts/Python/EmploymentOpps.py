# ----------------------------------------------------------------------------------------
# EmploymentOpps.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-02-17
# Last Edit: 2016-03-16
# Creator:  Kirsten R. Hazler/Tracy Tien
#
# Summary:
#  Creates a raster representing employment opportunities within a specified drive time
#
# Syntax:
# EmploymentOpps(inBizPts, fld_EmpNum, fld_ID, inCostSurf, maxTravTime, outEmpOpps)
# ----------------------------------------------------------------------------------------
ScriptDate = '2016-03-16' # Used for informative message down below

# Import necessary modules
import arcpy
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
import os # provides access to operating system functionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
import gc # garbage collection
from datetime import datetime # for time-stamping

# Script arguments to be input by user...
inBaseline = arcpy.GetParameterAsText(0)
   # Baseline raster with constant value 0 (optional)
inBizPts = arcpy.GetParameterAsText(1) 
   # Input point feature class representing business locations
   # Example:  BA_BUS_2015.gdb/us_businesses
fld_EmpNum = arcpy.GetParameterAsText(2) 
   # The name of the field containing the number of employees working at the location
   # Example:  EMPNUM
fld_ID = arcpy.GetParameterAsText(3)
   # The name of the field containing a unique ID for each business location
   # Example:  LOCNUM (String)
inCostSurf = arcpy.GetParameterAsText(4)
   # Input travel time cost surface, representing time required to traverse one meter
maxTravTime = arcpy.GetParameter(5) #
   # The maximum travel time, in minutes, to be considered in Cost Distance analysis
outEmpOpps = arcpy.GetParameterAsText(6)
   # Output raster representing employment opportunities

# Additional variables and environment settings
arcpy.env.overwriteOutput = True 
arcpy.env.outputCoordinateSystem = inCostSurf
scratchGDB = arcpy.env.scratchGDB 
arcpy.AddMessage("Scratch outputs will be stored here: %s" % scratchGDB)
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = inCostSurf # Set the snap raster 
myExtent = str(arcpy.Describe(inCostSurf).extent).replace(" NaN", "")
arcpy.env.extent = myExtent
arcpy.env.mask = inCostSurf
   
# Define functions for generating warning messages
def warnings(BizID):
   warnMsgs = arcpy.GetMessages(1)
   if warnMsgs:
      arcpy.AddWarning('Finished processing business %s, but there were some problems.' % BizID)
      arcpy.AddWarning(warnMsgs)
   else:
      arcpy.AddMessage('Business %s processing completed' % BizID)
      
def tback():
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

   arcpy.AddWarning(msgs)
   arcpy.AddWarning(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))
      
# Print helpful messages to geoprocessing window
arcpy.AddMessage("Your input business locations feature class is: \n %s" % inBizPts)
arcpy.AddMessage("Your input cost surface raster is: \n %s" % inCostSurf)
arcpy.AddMessage("Your final product output will be: \n %s" % outEmpOpps)
arcpy.AddMessage("The running script was last edited %s" % ScriptDate)

# If no Baseline raster was entered, create it; otherwise use the one provided
EmpSum = scratchGDB + os.sep + 'EmpSum'
if not inBaseline:
   # Make a constant raster set to zeros to cover the desired extent. 
   arcpy.AddMessage('Creating baseline zero raster...')
   Baseline = CreateConstantRaster (0, "INTEGER", 30, myExtent)
   Baseline.save(scratchGDB + os.sep + 'Baseline') 
   Baseline.save(EmpSum)
else:
   arcpy.AddMessage('Copying baseline zero raster...')
   arcpy.CopyRaster_management(inBaseline, EmpSum)

# Define output locations for temporary rasters created from each point. 
# Overwritten for each loop iteration.
ptRast = scratchGDB + os.sep + 'ptRast' # Rasterized version of point
ptTime = scratchGDB + os.sep + 'ptTime' # Raster representing travel time to current point
ptEmp = scratchGDB + os.sep + 'ptEmp' # Raster representing employment opps within max travel time

# Loop through the individual point features
myBizPts = arcpy.da.SearchCursor(inBizPts, [fld_ID, fld_EmpNum]) # Get the set of features

for myPt in myBizPts: # for each point in the set, do the following...
   try: # Even if one feature fails, script can proceed to next feature
      # Extract the relevant attributes from the data record
      BizID = myPt[0] 
      Num = myPt[1]
      
      # Add a progress message
      arcpy.AddMessage("\nWorking on business point %s..." % BizID)

      # # Reset processing extent, because ArcGIS is stupid.
      # myExtent = str(arcpy.Describe(inCostSurf).extent).replace(" NaN", "")
      # arcpy.env.extent = myExtent
      
      # Process:  Select (Analysis)
      # Create a temporary feature class including only the current business
      myCurrentPt = scratchGDB + os.sep + "tmpPt"
      myWhereClause = '"%s" = \'%s\' ' %(fld_ID, BizID)
      arcpy.Select_analysis (inBizPts, myCurrentPt, myWhereClause)
      
      # Convert the current point to raster.  Save it to ptRast.  
      # Make sure to snap to the cost surface and specify the correct cell size
      arcpy.AddMessage('Converting point to raster...')
      arcpy.PointToRaster_conversion (myCurrentPt, fld_EmpNum, ptRast, '', '', 30) 
      
      # Run the cost distance analysis out to the maximum travel time
      # Anything farther than that travel time will be NoData in the output
      # Save to ptTime
      arcpy.AddMessage('Conducting cost distance analysis...')
      TrvTm = CostDistance(ptRast, inCostSurf, maxTravTime)
      TrvTm.save(ptTime)
      
      # Recode (using CON) the cost distance raster so that the cell value is the employment number
      # where there's a travel time less than or equal to MaxTravTime.  Save that as ptEmp
      # WRONG:  ptEmp = Con (inCostSurf, fld_EmpNum, '', 'ptTime <= maxTravTime')
      arcpy.AddMessage('Creating raster representing number of persons employed...')
      Employed = Con (Raster(ptTime) <= maxTravTime, Num, 0)
      Employed.save(ptEmp)
      
      # Use Cell Statistics tool to add ptEmp to the EmpSum raster(sum)
      # Use the DATA option (so NoData cells are ignored)
      # Make sure to use the extent from EmpSum, not the smaller raster!!
      # Call the output tmpSum
      # Replace EmpSum with tmpSum
      # WRONG:  tmpSum = CellStatistics (ptEmp, "SUM", "DATA")
      arcpy.AddMessage('Summing employment numbers...')
      tmpSum = CellStatistics ([EmpSum, ptEmp], "SUM", "DATA")
      arcpy.CopyRaster_management(tmpSum, EmpSum)
      
      warnings(BizID)
   except:
      arcpy.AddWarning('Unable to process business %s' % BizID)
      tback()

arcpy.AddMessage('Saving final output...')      
arcpy.CopyRaster_management(EmpSum, outEmpOpps) # Save final output to designated output location








