# ---------------------------------------------------------------------------------------
# TravTmLimAcc.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-03-23
# Last Edit: 2016-03-24
# Creator:  Kirsten R. Hazler
#
# Summary:
# Creates a travel time raster that accounts for restricted connections to limited-access
# highways.  Travel transfer to and from limited access highways is restricted to 
# intersections between access ramps and highways (i.e., highway exits).  
#
# Usage:
# Before running this tool, use the "Create Travel Time Vertical Factor" and the 
# "Create Backdated Travel Time Cost Surface" tools to generate necessary inputs.
# ---------------------------------------------------------------------------------------

# Import arcpy module
import arcpy

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

# Script arguments
inTarget = arcpy.GetParameterAsText(0) # Input target raster
inCostSurf = arcpy.GetParameterAsText(1) # Input travel time cost surface
   # Example:  vm_Products.gdb\cs_TrvTm_2011
maxCost = arcpy.GetParameter(2)
inVertRast = arcpy.GetParameterAsText(3) # Input vertical factor raster
   # Example:  vm_Products.gdb\vf_TrvTm_2011
   # Most areas of map should have the value 0.  
   # Highway exits (where a highway and ramp intersect) should have the value of 1 cell width
   # Highways segments where there is no exit should have the value of 2 cell widths
outTravTime = arcpy.GetParameterAsText(4) # Output travel time raster

# Additional variables and environment settings
arcpy.env.outputCoordinateSystem = inCostSurf
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = inCostSurf # Set the snap raster 
arcpy.env.mask = inCostSurf

# Local variables (to set up vertical factor):
zeroFactor = 1.0
loCutAngle = -45
hiCutAngle = 45
vFact = VfBinary(zeroFactor, loCutAngle, hiCutAngle)

# Process: Path Distance
travTime = PathDistance (inTarget, inCostSurf, "", "", "", inVertRast, vFact, maxCost, "")
travTime.save(outTravTime)