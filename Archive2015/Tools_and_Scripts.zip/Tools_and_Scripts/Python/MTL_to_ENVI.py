# ------------------------------------------------------------------------------------------
# MTL_to_ENVI.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-10-22
# Last Edit:  2013-10-22
# Creator:  Kirsten R. Hazler
#
# NOTE:  This script is now obsolete, as I decided to run the MTL_to_ENVI.pro script
#        directly from IDL.
#
# Summary:
#     This script is a wrapper for IDL code which does the actual processing.  It iterates through all
#     files contained within the designated input directory and all its subdirectories, converts Landsat
#     TM files to ENVI format(.dat), and stores the new files in a specified output folder. Spectral bands
#     are saved as a multi-band file with an "S" prefix; the thermal band in a file with a "T" prefix.
#
#  Usage Tips:
#     (1) The script will ONLY work with Landsat TM data delivered as *.TIF files, which must include an 
#     associated metadata file in the format *_MTL.txt.
#     (2) Check the log file "MTL_log.txt" which is generated in the output directory. The log file 
#     contains a record of all files processed.
#
# Required Arguments:
#     inDir:  the directory containing source files
#     outDir:  the directory to contain the output files
#     outSuffix:  the suffix to add to the base name of all output files (e.g., '_UTG.dat')
# ------------------------------------------------------------------------------------------

# Import required modules
import envipy, arcpy, os, os.path, sys, traceback

### Script arguments hard-coded
##inDir = r"D:\VulnerabilityModel\Testing\Landsat_L1T\1434\2003\1434_20030825"
##outDir = r"D:\VulnerabilityModel\Testing\OUT_DAT"
##outSuffix = "_TEST1.dat"

### Script arguments to be input by user when run through Python Shell
##inDir = raw_input("Input inDir: ") 
##outDir = raw_input("Input outDir: ") 
##outSuffix = raw_input("Input outSuffix: ") 

# Script arguments to be input by user when run through ArcGIS tool
inDir = arcpy.GetParameterAsText(0)
#inDir = str(inDir)
arcpy.AddMessage("Your input directory is " + str(inDir))
outDir = arcpy.GetParameterAsText(1)
#outDir = str(outDir)
arcpy.AddMessage("Your output directory is " + str(outDir))
outSuffix = arcpy.GetParameterAsText(2)

try:
   # Create variables to reference the IDL script
   mytool = 'MTL_to_ENVI'
   #mytoolpath = r'D:\VulnerabilityModel\Tools_and_Scripts\IDL\MTL_to_ENVI.sav'
   mytoolpath = r'..\IDL\MTL_to_ENVI.sav'

   # Run the IDL script
   arcpy.AddMessage("Running IDL script")
   print "Running IDL script"
   
   envipy.RunTool(mytool, inDir, outDir, outSuffix, Library = mytoolpath)

   arcpy.AddMessage("Processing Complete")
   print "Processing Complete"
   arcpy.AddMessage("For details, see the log file 'MTL_log.txt' in your output directory")
   print "For details, see the log file 'MTL_log.txt' in your output directory"

except:
   # Error handling code swiped from "A Python Primer for ArcGIS"
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"
   arcpy.AddError(msgs)
   arcpy.AddError(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))

   print msgs
   print pymsg
   print arcpy.AddMessage(arcpy.GetMessages(1))
