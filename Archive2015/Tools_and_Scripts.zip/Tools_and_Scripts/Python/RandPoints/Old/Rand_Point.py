# -------------------------------------------------------------------------------------------------------
# Rand_Point.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-10
# Last Edit: 2013-06-13
# Creator:  Roy D. Gilb
#
# Summary:
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:

# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------





# Import required modules
import arcpy # provides access to all ArcGIS geoprocessing functions
import os # provides access to operating system funtionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
import random #used for generating random values
from arcpy import env

# Create random points in the features of a constraining feature class
# Number of points for each feature determined by the value in the field specified
outGDB = "C:/data/county.gdb"
outName = "randpeople"
conFC = "C:/data/county.gdb/blocks"
numField = "POP2000"
arcpy.CreateRandomPoints_management(outGDB, outName, conFC, "", numField)

# set workspace
env.workspace = "C:/data/county.gdb"

# Create fields for random values
fieldInt = "fieldInt"
fieldFlt = "fieldFlt"
arcpy.AddField_management(outName, fieldInt, "LONG") # add long integer field
arcpy.AddField_management(outName, fieldFlt, "FLOAT") # add float field

# Calculate random values between 1-100 in the new fields
arcpy.CalculateField_management(outName, fieldInt, "random.randint(1,100)","PYTHON","import random")
arcpy.CalculateField_management(outName, fieldFlt, "random.uniform(1,100)","PYTHON","import random")


#PYTHON SNIPPET - # Replace a layer/table view name with a path to a dataset (which can be a layer file) or create the layer/table view within the script
# The following inputs are layers or table views: "nlcd0630ml83c"
#rcpy.CreateRandomPoints_management("C:/Documents and Settings/skj95466/Desktop/Arc_Test","randpoints","#","nlcd0630ml83c","100","0 Unknown","POINT","0")

#FROM Hawth's Tool--- http://www.spatialecology.com/htools/rndpnts.php
#USEFUL ARC link ---- https://s3.amazonaws.com/VirtualGISClassroom/GIS%20Programming%20101%20ArcGIS%2010/The%20ArcPy%20Mapping%20Module/player.html

#FROM ARC

# CreateRandomPoints example 1 (Python window)
# The following Python window script demonstrates how to use the CreateRandomPoints tool in immediate mode:


# import arcpy
# arcpy.CreateRandomPoints_management("c:/data/project", "samplepoints", "c:/data/studyarea.shp", "", 500, "", "POINT", "")
                    

# CreateRandomPoints with Random Values example 2 (stand-alone Python script)
# The following stand-alone Python script demonstrates how to create random points with random values:


# #Name: RandomPointsRandomValues.py
# #Purpose: create random points with random values

# # Import system modules
# import arcpy, os, random
# from arcpy import env

# # Create random points in the features of a constraining feature class
# # Number of points for each feature determined by the value in the field specified
# outGDB = "C:/data/county.gdb"
# outName = "randpeople"
# conFC = "C:/data/county.gdb/blocks"
# numField = "POP2000"
# arcpy.CreateRandomPoints_management(outGDB, outName, conFC, "", numField)

# # set workspace
# env.workspace = "C:/data/county.gdb"

# # Create fields for random values
# fieldInt = "fieldInt"
# fieldFlt = "fieldFlt"
# arcpy.AddField_management(outName, fieldInt, "LONG") # add long integer field
# arcpy.AddField_management(outName, fieldFlt, "FLOAT") # add float field

# # Calculate random values between 1-100 in the new fields
# arcpy.CalculateField_management(outName, fieldInt, "random.randint(1,100)","PYTHON","import random")
# arcpy.CalculateField_management(outName, fieldFlt, "random.uniform(1,100)","PYTHON","import random")

                    

                    
# CreateRandomPoints example 3 (stand-alone Python script)
# The following stand-alone Python script demonstrates several methods to use the CreateRandomPoints tool:

# #Name: RandomPoints.py
# #Purpose: create several types of random points feature classes

# # Import system modules
# import arcpy, os
# from arcpy import env

# #set environment settings
# env.overWriteOutput = True

# # Create random points in an extent defined simply by numbers
# outFolder = "C:/data"
# numExtent = "0 0 1000 1000"
# numPoints = 100
# outName = "myRandPnts.shp"
# env.outputCoordinateSystem = "Coordinate Systems/Projected Coordinate Systems/World/Miller Cylindrical (world).prj"
# arcpy.CreateRandomPoints_management(outFolder, outName, "", numExtent, numPoints)
# env.outputCoordinateSystem = ""
 
# # Create random points in an extent defined by another feature class
# outName = "testpoints.shp"
# fcExtent = "C:/data/studyarea.shp"
# arcpy.CreateRandomPoints_management(outFolder, outName, "", fcExtent, numPoints)
 
# # Create random points in the features of a constraining feature class
# # Number of points for each feature determined by the value in the field specified
# outGDB = "C:/data/county.gdb"
# outName = "randpeople"
# conFC = "C:/data/county.gdb/blocks"
# numField = "POP2000"
# arcpy.CreateRandomPoints_management(outGDB, outName, conFC, "", numField)

# #create random points in the features of a constraining 
# #feature class with a minimum allowed distance
# outName = "constparcelpnts"
# conFC = "C:/data/county.gdb/parcels"
# numPoints = 10
# minDistance = "5 Feet"
# arcpy.CreateRandomPoints_management(outGDB, outName, conFC, "", numPoints, minDistance) 

# #Create random points with a multipoint output
# outName = "randomMPs"
# fcExtent = "C:/data/county.gdb/county"
# numPoints = 100
# numMP = 10
# arcpy.CreateRandomPoints_management(outGDB, outName, "", fcExtent, numPoints, "", "MULTIPOINT", numMP)
                    
