# GEN_RAND_POINTS2.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-19
# Last Edit: 2013-06-19
# Creator:  Roy D. Gilb
#
# Summary:
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:
#
#  *input_raster
#  *numpoints
#  *output_path
#  *min_dist
#  *excluded_class


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env

#parameters
inRaster = arcpy.GetParameterAsText(0)
#inPoly = arcpy.GetParameterAsText(1) 
outputDataset = arcpy.GetParameterAsText(1)
pointName = arcpy.GetParameterAsText(2)
polyOutput = arcpy.GetParameterAsText(3)
myExtent = arcpy.GetParameterAsText(4)
numPoints = arcpy.GetParameterAsText(5)
rasterField = arcpy.GetParameterAsText(6)
#minDistance = arcpy.GetParameterAsText(3)
#excludedClass = arcpy.GetParameterAsText(4)


arcpy.AddMessage("Creating polygon shapefile from input raster for processing.")
inPoly = arcpy.RasterToPolygon_conversion(inRaster, outputDataset, "NO_SIMPLIFY", rasterField)

arcpy.AddMessage("Success")


randPoints = arcpy.CreateRandomPoints_management(outputDataset, pointName, inPoly, myExtent, numPoints, "55 METERS")

# Check to make sure input data have spatial reference defined and matching; if not then exit gracefully
# arcpy.AddMessage("Checking spatial references...")
# print "Checking spatial references..."
# mySR_New = arcpy.Describe(New_SBBs).spatialReference.name
# mySR_Old = arcpy.Describe(Old_SBBs).spatialReference.name

# if mySR_New == "Unknown":
   # arcpy.AddError("Your new SBB feature class has no defined spatial reference.")
   # print "Your new SBB feature class has no defined spatial reference."
   # arcpy.AddError("Please define the spatial reference of your data or select a different feature class.")
   # arcpy.AddError("Then try this tool again.")

# elif mySR_New != mySR_Old :
   # arcpy.AddError("The spatial references of your input data do not match.")
   # print "The spatial references of your input data do not match."
   # arcpy.AddError("Please select input data with exactly matching spatial references.")
   # arcpy.AddError("Then try this tool again.")
