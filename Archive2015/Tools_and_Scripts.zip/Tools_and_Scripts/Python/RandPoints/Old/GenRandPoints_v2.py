# GEN_POINTS.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-24
# Last Edit: 2013-06-24
# Creator:  Roy D. Gilb
#
# Summary:
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:
#
#  *input_raster
#  *numpoints
#  *output_path
#  *min_dist
#  *excluded_class


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os, os.path
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env
from arcpy.sa import *

rootDir = 'C:\My Documents\Gilb_VulnMod\Arc_Test'
binDir = 'C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters'

arcpy.env.workspace = rootDir


#parameters
inRastText = arcpy.GetParameterAsText(0)
numPoints = arcpy.GetParameterAsText(1)
outputPath = arcpy.GetParameterAsText(2)
minDistance = arcpy.GetParameterAsText(3)
excludedClass = arcpy.GetParameterAsText(4)


#local variables
GME_file = 'C:\Software\SEGME.exe'
inRaster = Raster(inRastText)      #Create raster variable from parameter input text
myArray = arcpy.RasterToNumPyArray(inRastText)  #Create a numpyarray of the input raster for extracting unique values
uniqueVals = np.unique(myArray)                 #Extract unique values
binRoot = 'C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters'
count = 1
#myInfo = "genrandompnts(raster=\"" + inRastText + "\", "  + "extent=\"" + inRastText + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\", " + "minDist=25);"

#Inform user of processes
arcpy.AddMessage('Your parameters are:\nInput Raster: ' + inRastText + '\nNumber of Sample Points: ' + numPoints + '\nOutput Path: ' + outputPath)

#os.chdir("C:\My Documents\Gilb_VulnMod\Python_Scripts")

# #Write GME genrandompnts command to GME_SCRIPT.txt
# textFile = open("GME_SCRIPT1.txt", "w")
# textFile.write(myInfo)
# textFile.close()

# #RUN TEST
# subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\My Documents\Gilb_VulnMod\Python_Scripts\GME_SCRIPT.txt\");');

# arcpy.AddMessage('I am here again')




#THIS WORKS
#myInfo = "r'C:\\\Program Files\\\SpatialEcology\\\GME\\\SEGME.exe -c genrandompnts(raster=\\\"" + inRaster + "\\\", " + "extent=\\\"" + inRaster + "\\\", " + "sample=" + numPoints + ", out=\\\"" + outputPath + "\\\", " + " minDist=25);'"
#arcpy.AddMessage('myInfo string = ' + myInfo)

#Concatenated string test - DOESN"T WORk
#subp.call(myInfo);

#This works - hard coded though
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", extent=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", sample=55, out=\"C:\My Documents\Gilb_VulnMod\\Arc_Test\rand_points3.shp\", mindist=11);');

#Doesn't work
#subp.call("C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe genrandompnts(raster=inRaster, extent=\\\"inRaster\\\", sample=\\\"numPoints\\\", out=\\\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points17.shp\\\", \\\"mindist=minDistance\\\");");

#THIS LINE WORKS
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", extent=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", sample=1500, out=\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points17.shp\", mindist=11);');






#BINARY RASTER LOOPS
os.chdir("C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters")

arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))

arcpy.AddMessage('Beginning binary raster creation')
    
#Loops to create a binary raster for each feature class in the input raster
for val in uniqueVals:
    arcpy.AddMessage('Creating binary raster of class ' + str(val))   #Give user some processing feedback
   
    #Create a variable for the path/name of the unique binary rasters based on their value
    binRasterPath = 'C:\\My Documents\\Gilb_VulnMod\\Arc_Test\\BinRasters\\binaryClass' 
    binRasterPath = binRasterPath + str(val)
   
    #Extract just the values within the raster that match the unique class value for the iteration
    outRaster = Con((inRaster == int(val)), 1)
    outRaster.save(binRasterPath)                   #Save a binary raster with either 1 or NoData for each class value
    
    #Create properly formatted string for running GME genrandompnts command and write that string to a unique txt file
    myInfo = "genrandompnts(raster=\"" + inRastText + "\", "  + "extent=\"" + inRastText + "\", "  + "sample=" + numPoints + ", out=\"" + 'C:\\My Documents\\Gilb_VulnMod\\Arc_Test\\BinRasters\\binaryClass' + str(val) + ".shp" + "\", " + "minDist=25);"
    textFile = open("binaryClass" + str(val) + ".txt", "w")
    textFile.write(myInfo)
    textFile.close()

    
    
    #CORRECT RUN CALL TO TXT SCRIPT
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\My Documents\Gilb_VulnMod\Python_Scripts\GME_SCRIPT.txt\");');
    
   
try:
#Recursively walk through all directories staring with the root (binRoot)
   for root, dirs, myFiles in os.walk(binRoot):
      for filename in myFiles: 
         if filename.endswith(".txt"): #Find files that end with .txt (the GME script files)
            #print(str(count) + ") " + os.path.join(root, filename))    #More directory tracking if needed
     
            #Change current directory to the directory referenced by walk (contains tar.gz file) and extract the tar.gz file contained
            os.chdir(binRoot)
            gmeCall = r'C:\\Software\\SEGME.exe -c run(in=\"C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters' + '\\' + filename + '\\");'       #\");');        #[11: filename.find('.txt')] + '.txt\\'");"
            arcpy.AddMessage('GME Call is:  ' + gmeCall)
            subp.call(gmeCall);
            #subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters\");');
            
            arcpy.AddMessage((str(count) + ") Running file: " + filename))
            count = count + 1
            

#Error handling
except IOError:
   print("Error: can\'t find file or read data.")
else:
   print("Successfully ran GME files.")

  
arcpy.AddMessage('Successfully ran')  


#Create new fields in shpfiles to keep original class values 
    
    

#Merge shapefiles
tmp = "binaryClass"
os.chdir("C:\My Documents\Gilb_VulnMod\Arc_Test\BinRasters")
arcpy.env.workspace = binDir

fcs = arcpy.ListFeatureClasses()

for fc in fcs:
  arcpy.AddField_management(fc, 'shpname','text')
  arcpy.CalculateField_management(fc, 'shpname', '"'+fc+'"')
arcpy.Merge_management(fcs, 'myOut.shp')
    
    
    
    
    
    
#arcpy.AddMessage(rastDict)

     
# for key in rastDict:   
    # arcpy.AddMessage(str(key) + ' corresponds to ' + str(rastDict[key]))
    # binaryRast = arcpy.NumPyArrayToRaster(rastDict[key])
    
    # #ERROR HERE - NEED TO CODE HARD PATH OF EACH BINARY RASTER
    # #myInfo = "r'C:\\\Program Files\\\SpatialEcology\\\GME\\\SEGME.exe genrandompnts(raster=\\\"" + binaryRast + "\\\", " + "extent=\\\"" + inRaster + "\\\", " + "sample=" + numPoints + ", out=\\\"" + outputPath + "\\\", " + " minDist=25);'"
    # subp.call(myInfo)
    
#This line works, but I need to find out how to pass my parameter values
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", extent=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", sample=1000, out=\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points7.shp\", mindist=100);');

#Doesn't Work
#subp.call(GME_file -c \genrandompnts(raster=inputraster, extent=input_raster, sample=numpoints, out=output_path, mindist=min_dist);



