# GEN_POINTS.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-06-19
# Last Edit: 2013-06-19
# Creator:  Roy D. Gilb
#
# Summary:
#     
# Usage Tips:
#     
# Syntax:

# Required Arguments:
#
#  *input_raster
#  *numpoints
#  *output_path
#  *min_dist
#  *excluded_class


# Temporary feature classes:

# Spatial reference objects:

# Cursor objects:

# String objects (SQL):

# Other local variables:

# -------------------------------------------------------------------------------------------------------

import os
import sys
import arcpy
import traceback
import random
import numpy as np
import subprocess as subp
from arcpy import env

#parameters
inRaster = arcpy.GetParameterAsText(0)
numPoints = arcpy.GetParameterAsText(1)
outputPath = arcpy.GetParameterAsText(2)
minDistance = arcpy.GetParameterAsText(3)
excludedClass = arcpy.GetParameterAsText(4)


#local variables
GME_file = 'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe'
myInfo = "genrandompnts(raster=\"" + inRaster + "\", "  + "extent=\"" + inRaster + "\", "  + "sample=" + numPoints + ", out=\"" + outputPath + "\", " + "minDist=25);"

#Inform user of processes
arcpy.AddMessage('Your parameters are:\nInput Raster: ' + inRaster + '\nNumber of Sample Points: ' + numPoints + '\nOutput Path: ' + outputPath)

#Local Variables
myArray = arcpy.RasterToNumPyArray(inRaster)
[rows, cols] = myArray.shape
totalElements = cols * rows
uniqueVals = np.unique(myArray)
rastDict = {}
tempArray = np.zeros([rows, cols])


arcpy.AddMessage('I am here')

os.chdir("C:\My Documents\Gilb_VulnMod\Python_Scripts")

#Write GME genrandompnts command to GME_SCRIPT.txt
textFile = open("GME_SCRIPT1.txt", "w")
textFile.write(myInfo)
textFile.close()

#RUN TEST
subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c run(in=\"C:\My Documents\Gilb_VulnMod\Python_Scripts\GME_SCRIPT.txt\");');

arcpy.AddMessage('I am here again')





#myInfo = "r'C:\\\Program Files\\\SpatialEcology\\\GME\\\SEGME.exe -c genrandompnts(raster=\\\"" + inRaster + "\\\", " + "extent=\\\"" + inRaster + "\\\", " + "sample=" + numPoints + ", out=\\\"" + outputPath + "\\\", " + " minDist=25);'"
#arcpy.AddMessage('myInfo string = ' + myInfo)

#Concatenated string test - DOESN"T WORk
#subp.call(myInfo);

#This works - hard coded though
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", extent=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", sample=55, out=\"C:\My Documents\Gilb_VulnMod\\Arc_Test\rand_points3.shp\", mindist=11);');

#Doesn't work
#subp.call("C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe genrandompnts(raster=inRaster, extent=\\\"inRaster\\\", sample=\\\"numPoints\\\", out=\\\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points17.shp\\\", \\\"mindist=minDistance\\\");");

#THIS LINE WORKS
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", extent=\"C:\My Documents\Gilb_VulnMod\Arc_Test\nlcd_clip3\", sample=1500, out=\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points17.shp\", mindist=11);');






#BINARY RASTER LOOPS

#arcpy.AddMessage('Unique class values are: ' + str(uniqueVals))


#THIS IS TOO SLOW / CAUSES MEMORY ERROR
#Loops to create a binary raster for each feature class in the input raster
# for val in uniqueVals:
    # tempArr = np.zeros([rows, cols])       #initialize a temporary numpy Array for storing the binary rasters within the loop
    # arcpy.AddMessage('Creating binary raster of class ' + str(val))
    # for index, x in np.ndenumerate(myArray):
        # if val != x:
            # tempArr[index] = None
        # else:
            # tempArr[index] = val
        # rastDict["Class value is: #" + str(val)] = tempArr	

# arcpy.AddMessage(rastDict)

      
#This line works, but I need to find out how to pass my parameter values
#subp.call(r'C:\\Program Files\\SpatialEcology\\GME\\SEGME.exe -c genrandompnts(raster=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", extent=\"K:\Raster\LandCover\NLCD2006\nlcd0630ml83c\", sample=1000, out=\"C:\My Documents\Gilb_VulnMod\Arc_Test\rand_points7.shp\", mindist=100);');


#Doesn't Work
#subp.call(GME_file -c \genrandompnts(raster=inputraster, extent=input_raster, sample=numpoints, out=output_path, mindist=min_dist);



