# ----------------------------------------------------------------------------------------
# EmploymentDensity.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-03-30
# Last Edit: 2016-03-31
# Creator:  Kirsten R. Hazler/Roy Gilb
#
# Summary:
# Creates a raster representing density of employment opportunities
#
# Syntax:
# EmploymentDensity(inZIP_polys, fld_PolyZip, inZIP_pts, fld_PtZip, inZIP_tab, fld_TabZip, fld_EmpFlag, fld_Emp, inFlag_tab, fld_Flag, fld_RepNum, inLandCover, outGDB, outEmpDens)
# ----------------------------------------------------------------------------------------
ScriptDate = '2016-03-31' # Used for informative message down below

# Import necessary modules
import arcpy
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
import os # provides access to operating system functionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling

# Script arguments to be input by user...
inZIP_polys = arcpy.GetParameterAsText(0)
   # Polygon layer representing zip code areas
fld_PolyZip = arcpy.GetParameterAsText(1)
   # Field in polygon layer containing zip code
   # Default:  ZIP_CODE
inZIP_pts = arcpy.GetParameterAsText(2)
   # Point layer representing zip codes
fld_PtZip = arcpy.GetParameterAsText(3)
   # Field in point layer containing zip code
   # Default:  ZIP_CODE
inZIP_tab = arcpy.GetParameterAsText(4)
   # Table containing employment data tabulated by zip code
fld_TabZip = arcpy.GetParameterAsText(5)
   # Field in table containing zip code
   # Default:  ZIP
fld_EmpFlag = arcpy.GetParameterAsText(6)
   # Field in the ZIP table with flag values representing ranges of employee numbers
   # Default:  empflag
fld_Emp = arcpy.GetParameter(7)
   # Field containing employee numbers for unflagged records
   # Default:  emp
inFlag_tab = arcpy.GetParameterAsText(8)
   # Table translating EmpFlag values to employee numbers
fld_Flag = arcpy.GetParameter(9)
   # Field containing flag values
   # Default:  Flag
fld_RepNum = arcpy.GetParameter(10)
   # Field containing representative number of employees associated with flag
   # Default:  RepNum
inLandCover = arcpy.GetParameterAsText(11)
   # Raster representing NLCD Land Cover
outGDB = arcpy.GetParameterAsText(12)
   # Output GDB for intermediate rasters and tables
outEmpDens = arcpy.GetParameterAsText(13)
   # Output raster representing density of employment opportunities.

# Additional variables and environment settings
arcpy.env.overwriteOutput = True 
arcpy.env.outputCoordinateSystem = inLandCover
scratchGDB = arcpy.env.scratchGDB 
arcpy.AddMessage("Scratch outputs will be stored here: %s" % scratchGDB)
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = inLandCover # Set the snap raster 
myExtent = str(arcpy.Describe(inLandCover).extent).replace(" NaN", "")
arcpy.env.extent = myExtent
arcpy.env.mask = inLandCover
cellSize = 30 # Use this variable in all vector to raster conversions
   
# Print helpful messages to geoprocessing window
arcpy.AddMessage("Your ZIP code polygons: \n %s" % inZIP_polys)
arcpy.AddMessage("Your ZIP code points: \n %s" % inZIP_pts)
arcpy.AddMessage("Your ZIP code employment data table: \n %s" % inZIP_tab)
arcpy.AddMessage("Your Employee Flag dictionary table: \n %s" % inFlag_tab)
arcpy.AddMessage("Your land cover raster: \n %s" % inLandCover)
arcpy.AddMessage("The running script was last edited %s" % ScriptDate)

#Copy inputs to GDB
arcpy.AddMessage('Copying input data...')
zipTable = arcpy.TableToTable_conversion(inZIP_tab, outGDB, 'zipTable')
flagTable = arcpy.TableToTable_conversion(inFlag_tab, outGDB, 'flagTable')
zipPolys = arcpy.CopyFeatures_management (inZIP_polys, outGDB + os.sep + 'zipPolys')
zipPoints = arcpy.CopyFeatures_management (inZIP_pts, outGDB + os.sep + 'zipPoints')

arcpy.AddMessage('Adding and calculating new fields to Zip Code table...')
# Add a new long integer field, "EmpNum", to zipTable
arcpy.AddField_management(zipTable, 'EmpNum', 'LONG')

# Make a table view from zipTable
arcpy.MakeTableView_management (zipTable, 'zipView')

# Calculate the "EmpNum" field
# For unflagged records, use values from fld_Emp
where_clause = '"%s" IS NULL' %fld_EmpFlag
arcpy.SelectLayerByAttribute_management ('zipView', "NEW_SELECTION", where_clause)
expression = '!%s!'%fld_Emp
arcpy.CalculateField_management ('zipView', 'EmpNum', expression, 'PYTHON', '')

# For flagged records, use RepNum value associated with flag in inFlag_tab
myFlagRefs = arcpy.da.SearchCursor(flagTable, ['%s' %fld_Flag, '%s' %fld_RepNum])
for ref in myFlagRefs:
   flag = ref[0]
   repNum = ref[1]
   where_clause = '"%s" = %s' %(fld_EmpFlag, "'%s'" %flag)
   arcpy.SelectLayerByAttribute_management ('zipView', "NEW_SELECTION", where_clause)
   expression = repNum
   arcpy.CalculateField_management ('zipView', 'EmpNum', expression, 'PYTHON', '')

# Add a new long integer field, "intZip", to zipTable
# This should be populated with zip codes as integers (original zip code field is text)
arcpy.AddField_management(zipTable, 'intZip', 'LONG')
expression = 'int(!%s!)'%fld_TabZip
arcpy.CalculateField_management(zipTable, "intZIP", expression, "PYTHON")

# Join fields to zip points and polys
arcpy.AddMessage('Joining Zip table fields to polygons and points...')
fieldlist = ["EmpNum", "intZip"]
arcpy.JoinField_management (zipPolys, fld_PolyZip, zipTable, fld_TabZip, fieldlist)
arcpy.JoinField_management (zipPoints, fld_PtZip, zipTable, fld_TabZip, fieldlist)

arcpy.AddMessage('Converting polygons and points to rasters...')
# Convert zipPolys to a zonal raster (polyZones) using intZip as zone value
polyZones = outGDB + os.sep + 'polyZones'
arcpy.PolygonToRaster_conversion(zipPolys, "intZip", polyZones, "MAXIMUM_COMBINED_AREA", 'EmpNum', cellSize)

# Convert zipPolys to a value raster (polyVals) using EmpNum as value
polyVals = arcpy.PolygonToRaster_conversion(zipPolys, "EmpNum", outGDB + os.sep + 'polyVals', "MAXIMUM_COMBINED_AREA", 'EmpNum', cellSize)

# Convert zipPoints to a zonal raster (ptZones) using intZip as zone value
ptZones = arcpy.PointToRaster_conversion(zipPoints, "intZip", outGDB + os.sep + 'ptZones', "MOST_FREQUENT", "EmpNum", cellSize)  

# Convert zipPoints to a value raster (ptVals) using EmpNum as value
ptVals = arcpy.PointToRaster_conversion(zipPoints, "empNum", outGDB + os.sep + 'ptVals', "SUM", "", cellSize)  


## Hard-codes for trouble-shooting only
# polyZones = r'E:\scratch.gdb\polyZones'
# polyVals = r'E:\scratch.gdb\polyVals'
# ptZones = r'E:\scratch.gdb\ptZones'
# ptVals = r'E:\scratch.gdb\ptVals'
# zipZones = r'E:\scratch.gdb\zipZones'
# zipVals = r'E:\scratch.gdb\zipVals'   
# zipArea = r'E:\scratch.gdb\zipArea' 
   
# Make final zonal raster (ZipZones) in which:
   # any undeveloped cells (NLCD codes other than 21-24) are set to NoData
   # zip code zone from point raster overrides zip code zone from poly raster
arcpy.AddMessage('Creating zip code zonal raster...')
lc = Raster(inLandCover)
dev = Con (((lc == 21) | (lc == 22) | (lc == 23) | (lc == 24)), 1)  
   # This yields areas developed
dev.save(outGDB + os.sep + 'Developed')
ZoneOR = Con (~IsNull(polyZones) & ~IsNull(ptZones), ptZones, polyZones)  
   # This yields a raster with point zones overriding poly zones where they overlap
ZoneOR.save(outGDB + os.sep + 'ZoneOverride')
zipZones = Con(((IsNull(dev)==0) & (IsNull(ZoneOR)==0)), ZoneOR)
output = outGDB + os.sep + 'ZipZones'
zipZones.save(output)
## Lesson learned:  need to save intermediate rasters to disk, otherwise fails to save zipZones and throws an error.

# Make final value raster (ZipVals) in which:
   # any undeveloped cells (NLCD codes other than 21-24) are set to NoData
   # zip code value from point raster overrides zip code value from poly raster
arcpy.AddMessage('Creating zip code value raster...')
ValOR = Con (~IsNull(polyVals) & ~IsNull(ptVals), ptVals, polyVals)  
   #This yields a raster with point vals overriding poly vals where they overlap
ValOR.save(outGDB + os.sep + 'ValueOverride')
zipVals = Con(~IsNull(dev) & ~IsNull(ValOR), ValOR)
output = outGDB + os.sep + 'ZipVals'
zipVals.save(output)
zipVals = output

# Use Zonal Geometry tool to get area of each zip zone (output raster ZipArea)
arcpy.AddMessage('Calculating zonal geometry...')
zipArea = ZonalGeometry(zipZones, "Value", "AREA", cellSize)
output = outGDB + os.sep + 'ZipArea'
zipArea.save(output)
zipArea = output

# Use Raster Calc to get employment density per hectare
arcpy.AddMessage('Calculating employment density...')
EmpDens = Con(IsNull(zipArea),0,(900*Raster(zipVals)/Raster(zipArea)))
   # This yields employees per 30-m raster cell
# EmpDens = Con(IsNull(zipArea),0,(10000*Raster(zipVals)/Raster(zipArea)))
   # This yields employees per hectare
EmpDens.save(outEmpDens)