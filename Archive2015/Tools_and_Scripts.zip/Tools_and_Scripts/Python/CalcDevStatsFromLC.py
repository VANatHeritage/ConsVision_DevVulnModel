# ----------------------------------------------------------------------------------------
# CalcDevStatsFromLC.py
# Version: ArcGIS 10.3 / Python 2.7
# Creation Date:  2016-01-14
# Last Edit:  2016-02-22
# Creator:  Kirsten R. Hazler and Roy Gilb
# Description: Calculates total acres and hectares of different NLCD land cover categories 
# that were converted to development between two time points. 
# ----------------------------------------------------------------------------------------

# Import required standard modules
import arcpy, os, sys, traceback
from datetime import datetime
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")

# Script arguments to be input by user
in_LC1 = arcpy.GetParameterAsText(0) # NLCD landcover raster for time 1 (earlier)
in_LC2 = arcpy.GetParameterAsText(1) # NLCD landcover raster for time 2 (later)
yr1 = arcpy.GetParameterAsText(2) # Year of time 1
yr2 = arcpy.GetParameterAsText(3) # Year of time 2
in_ProcMask = arcpy.GetParameterAsText(4) # Raster mask defining area to process
out_GDB = arcpy.GetParameterAsText(5) # Geodatabase to hold output products

# Environment settings and derived variables
arcpy.env.overwriteOutput = True
arcpy.env.mask = in_ProcMask
r1 = Raster(in_LC1)
r2 = Raster(in_LC2)

# Process: Add Fields (year 1)
arcpy.AddField_management(in_LC1, "m2_%s" % yr1, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
arcpy.AddField_management(in_LC1, "ha_%s" % yr1, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
arcpy.AddField_management(in_LC1, "ac_%s" % yr1, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Fields (year 1)
arcpy.CalculateField_management(in_LC1, "m2_%s" % yr1, "[Count]*900", "VB", "")
arcpy.CalculateField_management(in_LC1, "ha_%s" % yr1, "[Area_Meters_%s]*0.0001" % yr1, "VB", "")
arcpy.CalculateField_management(in_LC1, "ac_%s" % yr1, "[Area_Meters_%s]*0.000247105381" % yr1, "VB", "")

# Process: Raster Calculator : Determine where development occurred between times 1 and 2
nd1 = Con ((r1 != 21) & (r1 != 22) & (r1 != 23) & (r1 != 24), 1, 0)
   # This yields areas assumed not developed in year 1
d2 = Con ((r2 == 21) | (r2 == 22) | (r2 == 23) | (r2 == 24) | (r2 == 31), 1, 0)
   # This yields areas assumed developed in year 2
tmpNewDev = Con ((nd1 == 1) & (d2 == 1), r1, 0)
   # This yields areas that transitioned from undeveloped to developed
NewDev = SetNull (tmpNewDev, tmpNewDev, "VALUE = 0")
NewDev.save(out_GDB + os.sep + 'NewDev')

# Process: Add Fields (year 2)
arcpy.AddField_management(NewDev, "m2_dev_%s" % yr2, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
arcpy.AddField_management(NewDev, "ha_dev_%s" % yr2, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")
arcpy.AddField_management(NewDev, "ac_dev_%s" % yr2, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Fields (year 2)
arcpy.CalculateField_management(NewDev, "m2_dev_%s" % yr2, "[Count]*900", "VB", "")
arcpy.CalculateField_management(NewDev, "ha_dev_%s" % yr2, "[Area_Meters_Converted]*0.0001", "VB", "")
arcpy.CalculateField_management(NewDev, "ac_dev_%s" % yr2, "[Area_Meters_Converted]*0.000247105381 ", "VB", "")

# Process: Join Field
# This appends the fields containing year 1 amounts of each land cover type
arcpy.JoinField_management(NewDev, "Value", in_LC1, "Value", "m2_%s;ha_%s;ac_%s" % (yr1, yr1, yr1))

# Process: Add Field
# This adds a field to hold the percent of land that transitioned from undeveloped
arcpy.AddField_management(NewDev, "PercDev", "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field
arcpy.CalculateField_management(NewDev, "PercDev", "100* ([m2_dev_%s]/ [m2_%s])" % (yr2, yr1), "VB", "")

#### Still to do:  
   # Create a similar, separate script that determines development status based on 
   # imperviousness, rather than on landcover.  You'll need both landcover and 
   # imperviousness rasters as inputs for this. Include a parameter to let the user 
   # determine what level of imperviousness constitutes "developed".
   # E.g., if user enters 5, anything less than 5% impervious is considered undeveloped 
   # and anything greater than or equal to 5% impervious is considered developed.
   # In this case, something classed as forest in the land cover could still be counted 
   # as developed based on imperviousness
   
   # Create a separate script that summarizes amount and percent new development by 
   # simplified classes based on a remap table specified by user.