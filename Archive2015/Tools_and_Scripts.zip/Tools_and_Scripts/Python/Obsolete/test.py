from ENVI_MetadataOps import ReplaceMetaFromDict as rm, CreateMetaDict as cm
SrcImg = r'D:\VulnMod_Testing\TOA_src\140342006181_STOA.hdr'
myDict = cm(SrcImg)
myDict.keys()
myDict['map info'] = 'replaced map info'
myDict['description'] = 'replaced description'
myKeyList = ['map info', 'description']
myNewHdr = rm(SrcImg, myKeyList, myDict)

