# ---------------------------------------------------------------------------
# TravTmWithVertFact.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-03-23
# Last Edit: 2016-03-23
# Creator:  Kirsten R. Hazler
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy

# Check out ArcGIS Spatial Analyst extension license and modules
arcpy.CheckOutExtension("Spatial")
from arcpy.sa import *

# Script arguments
inTarget = arcpy.GetParameterAsText(0)
inCostSurf = arcpy.GetParameterAsText(1)
inVertRast = arcpy.GetParameterAsText(2)
outTravTime = arcpy.GetParameterAsText(3)

# Local variables:
vFact = "BINARY 1 -45 45"

# Process: Path Distance
travTime = PathDistance (inTarget, inCostSurf, "", "", "", inVertRast, vFact)