# ----------------------------------------------------------------------------------------------
# CLIPMASK_NLCD_by_SHP.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-12-05
# Last Edit: 2013-12-11
# Creator: Kirsten R. Hazler
#
# Summary:  
#     Clips a large NLCD image to a set of WRS footprint shapefiles, 
#     outputting a separate subset raster for each shapefile. 
#
# Usage Tips:
#     A specific naming convention for shapefiles is required for this script to run correctly.
#     Shapefiles should be named SideBuff#####.shp, where ##### signifies the path/row of the
#     footprint
#
#     The set of shapefiles used for clipping must be in the same projection as the source image.
#     Otherwise results may not be as expected.
#
#     Check the log file "CLIP_LOG.txt" which is generated in the image output directory.  The
#     log file will contain a record of all files processed (or failed to process).
#
# Required Arguments:
#     srcImg: The NLCD image to be subsetted
#     ShpDir: Directory containing shapefiles defining the areas to clip
#     ClipDir: Directory to contain output clipped/masked images
#     outPrefix:  Filename prefix to be added to output images
# ----------------------------------------------------------------------------------------------

# Import required standard modules
import arcpy, os, os.path as path, sys, traceback, datetime, re
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta, CreateMetaDict as CreateMeta, DeleteMeta as DelMeta, ENVI_HDRfix as hdrfix

# Declare a timestamp variable
timestamp = datetime.datetime.now()

# Script arguments hard-coded
srcImg = r'E:\NLCD\NLCD_Proc\UTM17\nlcd2006_nochg_hom_rcl_utm17.dat'
ShpDir = r'D:\VulnerabilityModel\Shapefiles\WRS_Footprints\Buffered_Footprints\UTM17'
ClipDir = r'D:\VulnerabilityModel\NLCD_Proc\Clips_UTM17'
outPrefix = 'nlcd2006_nochg_hom_'

#Get the list shapes to use
myShps = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(ShpDir)
             for f in files if (f.endswith('.shp') and not f.endswith('vqt.shp'))]

arcpy.env.overwriteOutput = True #Existing data may be overwritten

#Create and open a log file to write processing records
mylogfile = "ClipMask_log.txt"
mylogfile = ClipDir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Clip Mask Processing Log" + "\n" + "\n")
mylog.write("Source image: " + srcImg + "\n")
mylog.write("Shapefile directory: " + ShpDir + "\n")
mylog.write("Directory to store output clipped images: " + ClipDir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")

#Loop through the image set
for SHP in myShps:
   try:
      print "Working on " + SHP
      
      #Extract the 5-digit WRS path/row identifier
      #Modify this bit if naming convention changes
      PathRow = basename(SHP)[8:13]
      
      #Declare output path
      outImg = ClipDir + path.sep + outPrefix + PathRow + '.dat'
      
      print srcImg
      print outImg
      print SHP
      
      #Clip the image
      print "Clipping..."
      arcpy.Clip_management (srcImg, "#", outImg, SHP, "0", "ClippingGeometry") 
      timestamp = datetime.datetime.now()
      
      # Then do other text-processing cleanup with the TCimg header
      hdrfix(outImg)
      myMetaDict = dict()
      myMetaDict['description'] = '{Clipped, Homogeneous, No-Change NLCD 2001/2006 Landcover [%s]}' %datetime.datetime.now() 
      myMetaDict['file type'] = 'ENVI Classification'
      myMetaDict['classes'] = '16'
      myMetaDict['class lookup'] = '{0,0,0,71,107,161,222,202,202,217,148,130,238,0,0,171,0,0,179,174,163,104,171,99,28,99,48,181,202,143,204,186,125,227, 227, 194, 220, 217, 61,171,112,40,186,217,235,112,163,186}'
      myMetaDict['class names'] = '{0,11,21,22,23,24,31,41,42,43,52,71,81,82,90,95}'
      myMetaDict['data ignore value'] = '0'
      myMetaDict['lineage'] = 'See the document NLCD_Processing.odt'
      myKeyList = ('description', 'file type', 'classes', 'class lookup', 'class names', 'data ignore value', 'lineage')
      for myKey in myKeyList:
         print myKey + ' = ' + myMetaDict[myKey]
      ReplMeta(outImg, myKeyList, myMetaDict)
      
      #Confirmation of successful processing
      print "Successfully created clip for " + SHP
      mylog.write("Successfully created clip for " + SHP + "\n")
          
   except:
      mylog.write("Failed to produce clip for " + SHP + "\n")
      
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))

      print msgs
      print pymsg
      print arcpy.AddMessage(arcpy.GetMessages(1))
      
# Clean up (delete) the auxiliary files created by Arc
delList = [os.path.join(dirpath, f)
          for dirpath, dirnames, files in os.walk(ClipDir)
          for f in files if f.endswith(('.ovr', '.xml'))]
for f in delList:
   os.remove(f)

# Update the timestamp
timestamp = datetime.datetime.now()
mylog.write("Program execution completed at " + str(timestamp) + "\n")      
mylog.close()
   



