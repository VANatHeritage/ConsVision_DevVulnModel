# ----------------------------------------------------------------------------------------
# EmploymentDensity.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-03-30
# Last Edit: 2016-03-30
# Creator:  Kirsten R. Hazler/Roy Gilb
#
# Summary:
# Creates a raster representing density of employment opportunities
#
# Syntax:
# EmploymentDensity(inZIP_polys, fld_PolyZip, inZIP_pts, fld_PtZip, inZIP_tab, fld_TabZip, fld_EmpFlag, fld_Emp, inFlag_tab, fld_Flag, fld_RepNum, inLandCover, outEmpDens)
# ----------------------------------------------------------------------------------------
ScriptDate = '2016-03-30' # Used for informative message down below

# Import necessary modules
import arcpy
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
import os # provides access to operating system functionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling

# Script arguments to be input by user...
inZIP_polys = arcpy.GetParameterAsText(0)
   # Polygon layer representing zip code areas
fld_PolyZip = arcpy.GetParameterAsText(1)
   # Field in polygon layer containing zip code
   # Default:  ZIP_CODE
inZIP_pts = arcpy.GetParameterAsText(2)
   # Point layer representing zip codes
fld_PtZip = arcpy.GetParameterAsText(3)
   # Field in point layer containing zip code
   # Default:  ZIP_CODE
inZIP_tab = arcpy.GetParameterAsText(4)
   # Table containing employment data tabulated by zip code
fld_TabZip = arcpy.GetParameterAsText(5)
   # Field in table containing zip code
   # Default:  ZIP
fld_EmpFlag = arcpy.GetParameterAsText(6)
   # Field in the ZIP table with flag values representing ranges of employee numbers
   # Default:  empflag
fld_Emp = arcpy.GetParameter(7)
   # Field containing employee numbers for unflagged records
   # Default:  emp
inFlag_tab = arcpy.GetParameterAsText(8)
   # Table translating EmpFlag values to employee numbers
fld_Flag = arcpy.GetParameter(9)
   # Field containing flag values
   # Default:  Flag
fld_RepNum = arcpy.GetParameter(10)
   # Field containing representative number of employees associated with flag
   # Default:  RepNum
inLandCover = arcpy.GetParameterAsText(11)
   # Raster representing NLCD Land Cover
outEmpDens = arcpy.GetParameterAsText(12)
   # Output raster representing density of employment opportunities.

# Additional variables and environment settings
arcpy.env.overwriteOutput = True 
arcpy.env.outputCoordinateSystem = inLandCover
scratchGDB = arcpy.env.scratchGDB 
arcpy.AddMessage("Scratch outputs will be stored here: %s" % scratchGDB)
arcpy.env.overwriteOutput = True # Existing data may be overwritten
arcpy.env.snapRaster = inLandCover # Set the snap raster 
myExtent = str(arcpy.Describe(inLandCover).extent).replace(" NaN", "")
arcpy.env.extent = myExtent
arcpy.env.mask = inLandCover
cellSize = 30 # Use this variable in all vector to raster conversions
   
# Print helpful messages to geoprocessing window
arcpy.AddMessage("Your ZIP code polygons: \n %s" % inZIP_polys)
arcpy.AddMessage("Your ZIP code points: \n %s" % inZIP_pts)
arcpy.AddMessage("Your ZIP code employment data table: \n %s" % inZIP_tab)
arcpy.AddMessage("Your Employee Flag dictionary table: \n %s" % inFlag_tab)
arcpy.AddMessage("Your land cover raster: \n %s" % inLandCover)
arcpy.AddMessage("The running script was last edited %s" % ScriptDate)

# Add code to pseudo-code below.  
# Also add helpful messages and error handling as needed.

# Add a new long integer field, "EmpNum", to inZIP_tab

# Calculate the "EmpNum" field
# For unflagged records, use values from fld_Emp
# For flagged records, use RepNum value associated with flag in inFlag_tab

# Add a new long integer field, "intZip", to inZIP_tab
# This should be populated with zip codes as integers (original zip code field is text)

# Join the EmpNum and intZip fields from inZIP_tab to inZIP_polys
   # IMPORTANT:  Use "Join Field" tool, not a temporary join
   # Join based on text field version of zip code 

# Join the EmpNum and intZip fields from inZIP_tab to inZIP_pts, same procedure as with polys

# Convert inZIP_polys to a zonal raster (polyZones) using intZip as zone value
   # Cell assignment: max combined area
   # Priority field:  EmpNum

# Convert inZIP_polys to a value raster (polyVals) using EmpNum as value
   # Cell assignment: max combined area
   # Priority field:  EmpNum

# Convert inZIP_pts to a zonal raster (ptZones) using intZip as zone value
   # Cell assignment type: most frequent (in some cases a code will be lost; that's okay)
   # Priority field:  EmpNum

# Convert inZIP_pts to a value raster (ptVals) using EmpNum as value
   # Cell assignment type: sum

# Make final zonal raster (ZipZones) in which:
   # any undeveloped cells (NLCD codes other than 21-24) are set to NoData
   # zip code zone from point raster overrides zip code zone from poly raster
   
# Make final value raster (ZipVals) in which:
   # any undeveloped cells (NLCD codes other than 21-24) are set to NoData
   # zip code value from point raster overrides zip code value from poly raster

# Use Zonal Geometry tool to get area of each zip zone (output raster ZipArea)

# Use Raster Calc to get employment density per hectare
   # EmpDens = 10000*ZipVals/ZipArea
   # After calc, set NoData cells to 0






