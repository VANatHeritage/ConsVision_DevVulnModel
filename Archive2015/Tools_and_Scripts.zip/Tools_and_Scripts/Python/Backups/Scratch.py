# -------------------------------------------------------------------------------------------------------
# EmploymentOpps.py
# Version:  ArcGIS 10.3.1 / Python 2.7.8
# Creation Date: 2016-02-17
# Last Edit: 2016-02-17
# Creator:  Kirsten R. Hazler
#
# Summary:
#  Creates a raster representing employment opportunities 
# -------------------------------------------------------------------------------------------------------
ScriptDate = '2016-02-17' # Used for informative message down below

# Import necessary modules
import arcpy
from arcpy.sa import *
arcpy.CheckOutExtension("Spatial")
import os # provides access to operating system functionality such as file and directory paths
import sys # provides access to Python system functions
import traceback # used for error handling
import gc # garbage collection
from datetime import datetime # for time-stamping

# Script arguments to be input by user...
inBizPts = arcpy.GetParameterAsText(0) 
   # Input point feature class representing business locations
fld_EmpNum = arcpy.GetParameterAsText(1) 
   # The name of the field containing the number of employees working at the location
fld_ID = arcpy.GetParameterAsText(2)
   # The name of the field containing a unique ID for each business location
inCostSurf = arcpy.GetParameterAs Text(2)
   # Input travel time cost surface, representing time required to traverse one meter
scratchGDB = arcpy.GetParameterAsText(3) 
   # A geodatabase for storing intermediate/scratch products
outputGDB = arcpy.GetParameterAsText(4) 
   # An geodatabase for storing final products

# Set overwrite option so that existing data may be overwritten
arcpy.env.overwriteOutput = True 
   
# Define functions for generating warning messages
def warnings(BizID):
   warnMsgs = arcpy.GetMessages(1)
   if warnMsgs:
      arcpy.AddWarning('Finished processing business %s, but there were some problems.' % str(BizID))
      arcpy.AddWarning(warnMsgs)
   else:
      arcpy.AddMessage('Business %s processing completed' % str(BizID))
      
def tback():
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

   arcpy.AddError(msgs)
   arcpy.AddError(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))

# Make a stupid joke   
arcpy.AddMessage('Why did the programmer cross the road?')
arcpy.AddMessage('To get away from the Python.')
arcpy.AddMessage('Ha ha ha.')
      
# Print helpful messages to geoprocessing window
arcpy.AddMessage("Your input business locations feature class is: \n %s" % inBizPts)
arcpy.AddMessage("Your input cost surface raster is: \n %s" % inCostSurf)
arcpy.AddMessage("Your intermediate products will be stored in: \n %s" % scratchGDB)
arcpy.AddMessage("Your final products will be stored in: \n %s" % outGDB)
arcpy.AddMessage("The running script was last edited %s" % ScriptDate)

try:
   arcpy.AddMessage('Prepping input procedural features')
   # Process: Copy Features
   tmpPF = scratchGDB + os.sep + 'tmpPF'
   arcpy.CopyFeatures_management(Input_PF, tmpPF, "", "0", "0", "0")

   # Process: Add Field (fltBuffer)
   arcpy.AddField_management(tmpPF, "fltBuffer", "FLOAT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

   # Process: Add Field (intRule)
   arcpy.AddField_management(tmpPF, "intRule", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

   # Process: Calculate Field (fltBuffer)
   expression1 = "string2float(!" + fld_Buffer + "!)"
   codeblock1 = """def string2float(myString):
      try:
         myFloat = float(myString)
      except:
         myFloat = 0
      return myFloat"""
   arcpy.CalculateField_management(tmpPF, "fltBuffer", expression1, "PYTHON", codeblock1)

   # Process: Calculate Field (intRule)
   expression2 = "string2int(!" + fld_Rule + "!)"
   codeblock2 = """def string2int(myString):
      try:
         myInteger = int(myString)
      except:
         myInteger = 0
      return myInteger"""
   arcpy.CalculateField_management(tmpPF, "intRule", expression2, "PYTHON", codeblock2)
except:
   arcpy.AddError('Unable to complete intitial pre-processing necessary for all further steps.')
   tback()
   quit()

arcpy.AddMessage('Beginning SBB creation.  This will take hours if you are running all features statewide.')
try:
   arcpy.AddMessage('Processing the simple defined-buffer features')
   # Process: Select (Defined Buffer Rules)
   PF_DefBuff = scratchGDB + os.sep + 'PF_DefBuff'
   arcpy.Select_analysis(tmpPF, PF_DefBuff, "( intRule in (1,2,3,4,10,11,12,13,14)) AND ( fltBuffer <> 0)")

   # Process: Buffer
   SBB_DefBuff = scratchGDB + os.sep + 'SBB_DefBuff'
   arcpy.Buffer_analysis(PF_DefBuff, SBB_DefBuff, "fltBuffer", "FULL", "ROUND", "NONE", "", "PLANAR")
   arcpy.AddMessage('Simple buffer SBBs completed')
except:
   arcpy.AddWarning('Unable to process the simple buffer features')
   tback()

try:
   arcpy.AddMessage('Processing the no-buffer features')
   # Process: Select (No-Buffer Rules)
   SBB_NoBuff = scratchGDB + os.sep + 'SBB_NoBuff'
   arcpy.Select_analysis(tmpPF, SBB_NoBuff, "(intRule = 15) OR ((intRule = 13) and (fltBuffer = 0))")
   arcpy.AddMessage('No-buffer SBBs completed')
except:
   arcpy.AddWarning('Unable to process the no-buffer features.')
   tback()

try:
   arcpy.AddMessage('Processing the Rule 5 features')
   # Process: Make Feature Layer (Rule 5)
   arcpy.MakeFeatureLayer_management(tmpPF, "lyr_PF5", "intRule = 5")

   # Process: Create Rule 5 Site Building Blocks
   SBB_rule5 = scratchGDB + os.sep + 'SBB_rule5'
   arcpy.CreateRule5SBB_sbbTools("lyr_PF5", fld_SFID, Input_NWI5, Input_FDIR, SBB_rule5)
   warnings(5)
except:
   arcpy.AddWarning('Unable to process Rule 5 features')
   tback()

try:
   arcpy.AddMessage('Processing the Rule 6 features')
   # Process: Make Feature Layer (Rule 6)
   arcpy.MakeFeatureLayer_management(tmpPF, "lyr_PF6", "intRule = 6")

   # Process: Create Rule 6 Site Building Blocks
   SBB_rule6 = scratchGDB + os.sep + 'SBB_rule6'
   arcpy.CreateRule6SBB_sbbTools("lyr_PF6", fld_SFID, Input_NWI67, Input_FDIR, SBB_rule6)
   warnings(6)
except:
   arcpy.AddWarning('Unable to process Rule 6 features')
   tback()

try:
   arcpy.AddMessage('Processing the Rule 7 features')
   # Process: Make Feature Layer (Rule 7)
   arcpy.MakeFeatureLayer_management(tmpPF, "lyr_PF7", "intRule = 7")

   # Process: Create Rule 7 Site Building Blocks
   SBB_rule7 = scratchGDB + os.sep + 'SBB_rule7'
   arcpy.CreateRule7SBB_sbbTools("lyr_PF7", fld_SFID, Input_NWI67, SBB_rule7)
   warnings(7)
except:
   arcpy.AddWarning('Unable to process Rule 7 features')
   tback()

try:
   arcpy.AddMessage('Processing the Rule 8 features')
   # Process: Make Feature Layer (Rule 8)
   arcpy.MakeFeatureLayer_management(tmpPF, "lyr_PF8", "intRule = 8")

   # Process: Create Rule 8 Site Building Blocks
   SBB_rule8 = scratchGDB + os.sep + 'SBB_rule8'
   arcpy.CreateRule8SBB_sbbTools("lyr_PF8", fld_SFID, Input_FDIR, SBB_rule8)
   warnings(8)
except:
   arcpy.AddWarning('Unable to process Rule 8 features')
   tback()

try:
   arcpy.AddMessage('Processing the Rule 9 features')
   # Process: Make Feature Layer (Rule 9)
   arcpy.MakeFeatureLayer_management(tmpPF, "lyr_PF9", "intRule = 9")

   # Process: Create Rule 9 Site Building Blocks
   SBB_rule9 = scratchGDB + os.sep + 'SBB_rule9'
   arcpy.CreateRule9SBB_sbbTools("lyr_PF9", fld_SFID, Input_NWI9, SBB_rule9)
   warnings(9)
except:
   arcpy.AddWarning('Unable to process Rule 9 features')
   tback()

try:
   arcpy.AddMessage('Merging all the SBB features into one feature class')
   # Process: Merge
   inputs = [SBB_DefBuff, SBB_NoBuff, SBB_rule5, SBB_rule6, SBB_rule7, SBB_rule8, SBB_rule9]
   arcpy.Merge_management (inputs, Output_SBB)
except:
   arcpy.AddWarning('Unable to merge all SBB features')
   tback()









