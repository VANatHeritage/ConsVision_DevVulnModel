# ----------------------------------------------------------------------------------------------
# SHP_to_EVF.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date: 2013-10-25
# Last Edit: 2013-10-25
# Creator: Kirsten R. Hazler
#
# Summary:  This script is a wrapper for IDL code which does the actual processing.  It converts a
# set of shapefiles (*.SHP) to ENVI vector files (*.EVF).  
#
# MAJOR DISCLAIMER:  This script should not be used because the underliying IDL script had issues
# and I ended up doing the SHP to EVF conversions manually.  This script is only retained for
# reference and possible source of code snippets.
#
# Usage Tips:
#     (1) The input shapefiles must have an associated PRJ file defining the projection parameters.
#     (2) Check the log file "EVF_log.txt" which is generated in the image output directory.  The
#     log file contains a record of all files processed.
#
# Required Arguments:
#     inSHPdir:  the directory containing the input SHP files
#     outEVFdir:  the directory to contain the output EVF files (ENVI vector files, derived from 
#                 shapefiles)
# ----------------------------------------------------------------------------------------------

# Import required modules
import envipy, arcpy, os, os.path, sys, traceback 

# Script arguments hard-coded
inSHPdir = r'E:\Dell_Working\VulnerabilityModel\Shapefiles\WRS_Footprints\Buffered_Footprints'
outEVFdir = r'E:\Dell_Working\VulnerabilityModel\Testing\EVF'

# # Script arguments to be input by user when run through ArcGIS tool
# inSHPdir = arcpy.GetParameterAsText(0)
# outEVFdir = arcpy.GetParameterAsText(1)

try:
   # Create variables to reference the IDL script
   mytoolpath = r'..\IDL'
   myVecTool = 'SHP_to_EVF'
   myVecToolPath = mytoolpath + os.sep + myVecTool + '.sav'

   # Run the IDL script converting shapefiles to ENVI vector files
   arcpy.AddMessage("Converting SHP to EVF...")
   print "Converting SHP to EVF"
   envipy.RunTool(myVecTool, inSHPdir, Library = myVecToolPath)
   
   arcpy.AddMessage("Processing Complete")
   print "Processing Complete"
   arcpy.AddMessage("For details, see the log file 'EVF_log.txt' in your output directory.")
   print "For details, see the log file 'EVF_log.txt' in your output directory."
   
except:
   # Error handling code swiped from "A Python Primer for ArcGIS"
   tb = sys.exc_info()[2]
   tbinfo = traceback.format_tb(tb)[0]
   pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
   msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

   arcpy.AddError(msgs)
   arcpy.AddError(pymsg)
   arcpy.AddMessage(arcpy.GetMessages(1))

   print msgs
   print pymsg
   print arcpy.AddMessage(arcpy.GetMessages(1))
   



