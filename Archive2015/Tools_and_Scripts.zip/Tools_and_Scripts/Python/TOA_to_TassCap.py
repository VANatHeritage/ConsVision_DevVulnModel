# ------------------------------------------------------------------------------------------
# TOA_to_TassCap.py
# Version:  ArcGIS 10.1 / Python 2.7 / IDL 8.2.3
# Creation Date:  2013-12-03
# Last Edit:  2013-12-03
# Creator:  Kirsten R. Hazler
#
# Summary:
#     This script is a wrapper for IDL code which does the actual processing.  It iterates through all
#     files contained within the designated input directory and all its subdirectories, converting
#     Top-of-Atmosphere reflectance images to tasseled cap images
#
#  Usage Tips:
#     (1) For multi-band images, this script assumes that the locations of the first band's NoData 
#     values are representative for all bands (that is, the mask is based entirely on the first
#     band.)
#     (2) This tool was developed to work with Landsat-derived files following a naming convention
#     where the first 5 characters (digits) in the source file name indicate the Landsat path/row.
#     These first 5 characters are used to name the corresponding masks used to set the outer periphery
#     to NoData values.
#
# Required Arguments:
#     SrcDir:  The directory containing source (top-of-atmosphere reflectance) images
#     MskDir:  The directory containing the binary mask images
#     TCdir:    The directory to contain output tasseled cap images
#     NoDataVal:  The number value representing "NoData" in the source and output images
# ------------------------------------------------------------------------------------------

# Import required standard modules
import os, os.path as path, sys, traceback, datetime, re, Tkinter, tkFileDialog
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta, CreateMetaDict as CreateMeta, DeleteMeta as DelMeta, ENVI_HDRfix as hdrfix
from CallSub import Call_IDLpro as ipro

# Declare a timestamp variable
timestamp = datetime.datetime.now()

# Prepare dialog - Tkinter gobblety-gook
# Make a top-level instance and hide since it is ugly and big.
root = Tkinter.Tk()
root.withdraw()

# Make it almost invisible - no decorations, 0 size, top left corner.
root.overrideredirect(True)
root.geometry('0x0+0+0')

# Show window again and lift it to top so it can get focus,
# otherwise dialogs will end up behind the terminal.
root.deiconify()
root.lift()
root.focus_force()

# Script arguments enter by user at prompts
SrcDir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory containing source images')
MskDir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory containing mask images')
TCdir = tkFileDialog.askdirectory(parent=root,initialdir='D:\\',
                                     title='Choose directory to store output tasseled cap images')
NoDataVal = raw_input('Enter a NoData value:\n')

## Hard-coded script arguments
#SrcDir = r"D:\VulnMod_Testing\TOA_src"
#MskDir = r"E:\Landsat\Landsat_PROC\MASKS"
#TCdir = r"D:\VulnMod_Testing\TCAP"
#NoDataVal = "999"

# Create variable to reference the IDL script
idl_pro = 'TOA_to_TassCap'

#Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(SrcDir)
             for f in files if f.endswith('.dat')]

#Create and open a log file to write processing records
mylogfile = "TassCap_log.txt"
mylogfile = TCdir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Tasseled Cap Processing Log" + "\n" + "\n")
mylog.write("Source image directory: " + SrcDir + "\n")
mylog.write("Mask image directory: " + MskDir + "\n")
mylog.write("Directory to store output tasseled cap images: " + TCdir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")
             
for SrcImg in mySrcImgs:
   try:
      print "Working on " + SrcImg
      
      # Determine the names of the corresponding mask image and output tassled cap image
      myRootName = os.path.splitext(basename(SrcImg))[0]
      PathRow = myRootName[0:5]
      MskImg = MskDir + path.sep + PathRow + '_MSK.dat'
      print "Corresponding mask image: " + MskImg
      myRootName = os.path.splitext(basename(SrcImg))[0]
      TCimg = TCdir + path.sep + myRootName + '_TC.dat'
      print "Output tassled cap image: " + TCimg
      
      # Gather the parameters into a list
      params_list = [SrcImg, MskImg, TCimg, NoDataVal]
      print params_list
      
      # Run the IDL script
      print "Running IDL script"
      idl_err = ipro(idl_pro, params_list)
      
      if len(idl_err) == 0 and os.path.isfile(TCimg):
         # Confirmation of successful processing
         print "Successfully created tassled cap image for %s" %SrcImg
         print "Now editing metadata..."
         
         try:
            # Then do other text-processing cleanup with the TCimg header
            hdrfix(TCimg)
            mySrcMeta = CreateMeta(SrcImg)
            myMetaDict = CreateMeta(TCimg)
            myMetaDict['description'] = 'Tassled Cap image [%s]' %datetime.datetime.now() 
            myOldLin = myMetaDict.get('lineage', 'missing')
            myNewLin = myOldLin.replace('}', ', Tasseled Cap Image Image: %s}' %TCimg)
            myMetaDict['lineage'] = myNewLin
            myMetaDict['acquisition time'] = mySrcMeta.get('acquisition time', 'missing')
            myMetaDict['data ignore value'] = '999'
            myKeyList = ('description', 'lineage', 'acquisition time', 'data ignore value')
            for myKey in myKeyList:
               print myKey + ' = ' + myMetaDict[myKey]
            ReplMeta(TCimg, myKeyList, myMetaDict)
            
         except:
            print "Tassled Cap image created, but metadata editing failed"
            # Error handling code modified from "A Python Primer for ArcGIS"
            tb = sys.exc_info()[2]
            tbinfo = traceback.format_tb(tb)[0]
            pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
            print pymsg
            print "Tasseled Cap processing failed for " + SrcImg
         
      else:
         print "Failed to produce tassled cap image for %s" %SrcImg
         print idl_err

   except:
      # Error handling code modified from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n " + str(sys.exc_info()[1])
      print pymsg
      print "Mask Build failed for " + SrcImg

print "Processing Complete"
print "For details, see the log file 'TCAP_IDL_log.txt' in your output directory"

# Update the timestamp
timestamp = datetime.datetime.now()
mylog.write("Program execution completed at " + str(timestamp) + "\n")      
mylog.close()
