# ----------------------------------------------------------------------------------------------
# ENVI_MetadataOps.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-11-19
# Last Edit: 2013-11-19
# Creator: Kirsten R. Hazler
#
# Summary: 
#  A set of functions for dealing with ENVI image metadata
# ----------------------------------------------------------------------------------------------

import sys, os, re

def CreateMetaDict(DATimg):
#  Creates a metadata dictionary from the header file (*.hdr) associated with 
#  an ENVI image file(*.dat).  

   # Get the name of the associated HDR file containing metadata
   rootnm, extn = DATimg.split('.')
   ImgHDR = rootnm + '.hdr'

   # Read the header file into a string, and do some cleanup
   f = open(ImgHDR)
   ImgHDRString = f.read()
   ImgHDRString = ImgHDRString.replace('ENVI\n', '')
   ImgHDRString = ImgHDRString.replace('{\n', '{')

   # Convert the header string into a list of tag, value tuples
   ImgHDRList = ImgHDRString.split('\n')
   ImgHDRList = [i for i in ImgHDRList if i != '']
   for index, item in enumerate(ImgHDRList):
      tag, value = item.split('=', 1)
      ImgHDRList[index] = (tag.strip(), value.strip())

   # Finally, convert the list to a dictionary   
   MetaDict = dict(ImgHDRList)
   return MetaDict

def ReplaceMetaFromDict(DATimg, KeyList, MetaDict):
#  Replaces the specified metadata items in a DAT image's header file (*.hdr) with new
#  values derived from a specified metadata dictionary.  The keyword list (KeyList) 
#  identifies the items to be changed.

   # Get the name of the associated HDR file containing metadata
   rootnm, extn = DATimg.split('.')
   ImgHDR = rootnm + '.hdr'
   
   # Read the header file into a string
   f = open(ImgHDR)
   ImgHDRString = f.read()
   f.close
   
   #Get rid of the messed-up band names produced by Arc
   #myBandsPattern = re.compile(r'band names = \{\n.+\}', re.DOTALL)
   #ImgHDRString = re.sub(myBandsPattern, '', ImgHDRString)
   
   #Additional string cleanup
   ImgHDRString = ImgHDRString.replace('{\n', '{')
   
   for Key in KeyList:
      # Get the value of the specified keyword from the dictionary, if it exists
      # If missing from the dictionary, default value is 'missing'.
      myMetValue = MetaDict.get(Key, 'missing')
      
      # Match the pattern in the header string
      myPattern = re.compile(Key + r' *= *.+\n')
      myMatch = re.search(myPattern, ImgHDRString)
      
      # Make the replacement in, or append to, the header string as applicable
      if myMetValue != 'missing': 
         mySubstitution = Key + ' = ' + myMetValue + '\n'
         if myMatch: # if match was found, substitute metadata in place
            ImgHDRString = ImgHDRString.replace(myMatch.group(),mySubstitution)
         else: # if match was not found, append new metadata to end
            ImgHDRString = ImgHDRString + mySubstitution
      
   # Write the changed string to the original header file
   f = open(ImgHDR, 'w')
   f.write(ImgHDRString)
   f.close
   
   return ImgHDRString
   
def DeleteMeta(DATimg, KeyList):
#  Deletes the specified metadata items in a DAT image's header file (*.hdr). The keyword 
#  list (KeyList) identifies the items to be removed.
 
#  Get the name of the associated HDR file containing metadata
   rootnm, extn = DATimg.split('.')
   ImgHDR = rootnm + '.hdr'
   
   # Read the header file into a string
   f = open(ImgHDR)
   ImgHDRString = f.read()
   f.close
   
   for Key in KeyList:
      # Match the pattern in the header string
      myPattern = re.compile(Key + r' *= *.+\n')
      myMatch = re.search(myPattern, ImgHDRString)
      mySubstitution = ""
      ImgHDRString = re.sub(myPattern, mySubstitution, ImgHDRString)
   
   # Write the changed string to the original header file
   f = open(ImgHDR, 'w')
   f.write(ImgHDRString)
   f.close
   
   return ImgHDRString
   
def ENVI_HDRfix(DATimg):
# Fixes ENVI header files so that each tag, value tuple is confined to a single line
   
   # Get the name of the associated HDR file containing metadata
   rootnm, extn = DATimg.split('.')
   ImgHDR = rootnm + '.hdr'
   
   f = open(ImgHDR)
   ImgHDRString = f.read()
   f.close
   
   try:   
      myPat = re.compile(r' = \{.+?\}', re.DOTALL)
      myMatches = re.findall(myPat, ImgHDRString)
      mySubs = [match.replace('{ \n', '{').replace('\n', '') for match in myMatches]
      for i in range(len(myMatches)):
         ImgHDRString = ImgHDRString.replace(myMatches[i], mySubs[i])
      
      f = open(ImgHDR, 'w')
      f.write(ImgHDRString)
      f.close
      
   except:
      print 'Skipping file'
      
   return ImgHDRString      