# ----------------------------------------------------------------------------------------------
# CLIPMASK_DAT_by_SHP.py
# Version:  ArcGIS 10.1 / Python 2.7
# Creation Date: 2013-10-24
# Last Edit: 2014-04-23
# Creator: Kirsten R. Hazler
#
# Summary:  
#     Clips all Landsat5-TM images (ENVI *.dat format) within a specified directory (including 
#     subdirectories) to their corresponding footprints which are defined by shapefiles (*.shp).
#     Image data outside the polygon boundaries is masked to NoData values.
#     This script matches the images to the correct vector files via a 5-digit Landsat path/row 
#     identifier.  This routine was developed to work with files that follow a very specific naming 
#     convention.  This script has limited error handling, and will fail or yield incorrect results
#     if the naming convention is not followed (see usage tips). 
#
# Usage Tips:
#     (1) This script will only work if both images and shapefiles are named according to a regular
#     convention, such that the path/row are identified in the names and images can be matched
#     to the correct footprint.  Each shapefile should contain only a single footprint polygon.
#        Example image name:  150342007127_STOA.dat
#        Example matching shapefile name:  SideBuff15034.shp
#
#     (2) Check the log file "CLIP_LOG.txt" which is generated in the image output directory.  The
#     log file will contain a record of all files processed (or failed to process).
#
# Required Arguments:
#     mySrcDir: Directory containing source images to be clipped
#     myVecDir: Directory containing shapefiles defining the areas to clip
#     myClipDir: Directory to contain output clipped/masked images
# ----------------------------------------------------------------------------------------------

# Import required standard modules
import arcpy, os, os.path as path, sys, traceback, datetime, re, Tkinter, tkFileDialog
from os.path import basename

# Import required custom modules and functions
from ENVI_MetadataOps import ReplaceMetaFromDict as ReplMeta
from ENVI_MetadataOps import CreateMetaDict as MetaDict

# Declare a timestamp variable
timestamp = datetime.datetime.now()

# # Script arguments hard-coded
# mySrcDir = r'D:\VulnMod_Testing\TOA_src'
# myVecDir = r'D:\VulnerabilityModel\Shapefiles\WRS_Footprints\Buffered_Footprints'
# myClipDir = r'D:\VulnMod_Testing\Clips'

# Prepare dialog - Tkinter gobblety-gook
# Make a top-level instance and hide since it is ugly and big.
root = Tkinter.Tk()
root.withdraw()

# Make it almost invisible - no decorations, 0 size, top left corner.
root.overrideredirect(True)
root.geometry('0x0+0+0')

# Show window again and lift it to top so it can get focus,
# otherwise dialogs will end up behind the terminal.
root.deiconify()
root.lift()
root.focus_force()

# Script arguments enter by user
mySrcDir = tkFileDialog.askdirectory(parent=root,initialdir="D:/",
                                     title='Choose directory containing source images')
myVecDir = tkFileDialog.askdirectory(parent=root,initialdir="D:/",
                                     title='Choose directory containing footprint shapefiles')
myClipDir = tkFileDialog.askdirectory(parent=root,initialdir="D:/",
                                     title='Choose directory to store output clipped images')

#Create "SPECT" and "THERM" subdirectories in output directory, if not yet present.
mySpectDir = myClipDir + path.sep + "SPECT"
myThermDir = myClipDir + path.sep + "THERM"
if not os.path.isdir(mySpectDir):
   os.mkdir(mySpectDir)
if not os.path.isdir(myThermDir):
   os.mkdir(myThermDir)

#Get the list of images to process
mySrcImgs = [os.path.join(dirpath, f)
             for dirpath, dirnames, files in os.walk(mySrcDir)
             for f in files if f.endswith('.dat')]

arcpy.env.overwriteOutput = True #Existing data may be overwritten

#Create and open a log file to write processing records
mylogfile = "ClipMask_log.txt"
mylogfile = myClipDir + path.sep + mylogfile
mylog = open(mylogfile, 'w')
mylog.write("Clip Mask Processing Log" + "\n" + "\n")
mylog.write("Source image directory: " + mySrcDir + "\n")
mylog.write("Shapefile directory: " + myVecDir + "\n")
mylog.write("Directory to store output clipped images: " + myClipDir + "\n")
mylog.write("Program execution started at " + str(timestamp) + "\n")

#Loop through the image set
for SrcImg in mySrcImgs:
   try:
      print "Working on " + SrcImg
      
      #Split the image basename from its extension
      ImgBN, ImgExt = path.splitext(basename(SrcImg))
      
      #Declare output paths
      #Thermal and spectral images go to different subdirectories (based on basename suffix)
      if ImgBN[-4:].upper() == "STOA":
         myOutDir = mySpectDir
      elif ImgBN[-4:].upper() == "TTOA":  
         myOutDir = myThermDir
      else:
         myOutDir = myClipDir
      myTmpDir = myClipDir + path.sep + 'Tmp'
      mySubset = myTmpDir + path.sep + ImgBN + '_tmp.dat'
      myClipImg = myOutDir + path.sep + ImgBN + '_CLP.dat'
      print myClipImg
      
      #Extract the 5-digit WRS path/row identifier
      #Modify this bit if naming convention changes
      myPathRow = ImgBN[:5] 
      print 'Image is in path/row ' + myPathRow 
      
      #Get the vector file with the corresponding path/row
      myVec = 'SideBuff' + myPathRow + '.shp'
      myVec = myVecDir + path.sep + myVec
      print 'Using file ' + myVec + ' to clip the image'
      
      #Check if the vector file exists; if not, print error and proceed to next image
      print 'Checking for existence of correct vector file...'
      if not os.path.isfile(myVec):
         #print message to log file and move on to next
         mylog.write("Can not clip image " + SrcImg + ": corresponding footprint not found." + "\n")
         print "Can not clip image " + SrcImg + ": corresponding footprint not found.  Moving on..."
         continue #skips back to the top of the loop for the next image
      
      #Clip the image
      print "Clipping..."
      arcpy.Clip_management (SrcImg, "#", myClipImg, myVec, "999", "ClippingGeometry") 
      timestamp = datetime.datetime.now()
      
      #Create metadata dictionary from source image, and modify some contents
      print "Preparing metadata..."
      myMetaDict = MetaDict(SrcImg)
      myMetaDict['description'] = 'Clip result [' + str(timestamp) + ']'
      myPrevProc = myMetaDict.pop('processing source image') #removes key, returns value
      myProcList = ['Source image: ' + myPrevProc] #create list of processing steps
      myProcList.append('TOA calibration result: ' + SrcImg)
      myProcList.append('Clip result: ' + myClipImg)
      myProcListMeta = '{' + '\n'.join(myProcList) + '}' #create string to add to metadata
      myMetaDict['lineage'] = myProcListMeta #creates new key and value
      myMetaDict['data ignore value'] = '999'
      
      #Replace or add medatadata in header file as needed
      print "Adding metadata..."
      myKeyList = ['description', 'lineage', 'band names', 'wavelength units', 'wavelength',
                   'data ignore value', 'acquisition time']
      myHdrString = ReplMeta(myClipImg, myKeyList, myMetaDict)
            
      #Confirmation of successful processing
      print "Successfully processed " + SrcImg
      mylog.write("Successfully processed " + SrcImg + "\n")
          
   except:
      mylog.write("Failed to clip image " + SrcImg + "\n")
      
      # Error handling code swiped from "A Python Primer for ArcGIS"
      tb = sys.exc_info()[2]
      tbinfo = traceback.format_tb(tb)[0]
      pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n "
      msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

      arcpy.AddError(msgs)
      arcpy.AddError(pymsg)
      arcpy.AddMessage(arcpy.GetMessages(1))

      print msgs
      print pymsg
      print arcpy.AddMessage(arcpy.GetMessages(1))
      
# Clean up (delete) the auxiliary files created by Arc
delList = [os.path.join(dirpath, f)
          for dirpath, dirnames, files in os.walk(myClipDir)
          for f in files if f.endswith(('.ovr', '.xml'))]
for f in delList:
   os.remove(f)

# Update the timestamp
timestamp = datetime.datetime.now()
mylog.write("Program execution completed at " + str(timestamp) + "\n")      
mylog.close()
   



